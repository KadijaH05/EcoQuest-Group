import { View, Text, StyleSheet, ScrollView, Pressable, Image, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Camera,
  MapPin,
  Award,
  Trophy,
  Recycle,
  Users,
  ArrowRight,
  Leaf,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { COLORS, FONTS, RADIUS, SPACING, SHADOWS } from '@/lib/theme';
import { ECOQUEST, STATS, FEATURES, COMMUNITY_IMAGES } from '@/lib/ecoquest-data';
import { SectionHeader } from '@/components/PageSection';

const FEATURE_ICONS = { camera: Camera, map: MapPin, award: Award, trophy: Trophy, recycle: Recycle, users: Users };

export default function HomeScreen() {
  const insets = useSafeAreaInsets();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxxl }}>
      {/* HERO */}
      <LinearGradient
        colors={[COLORS.heroDark, COLORS.heroGreen, COLORS.primary]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.hero}
      >
        <View style={{ height: insets.top }} />
        <View style={styles.heroInner}>
          <View style={styles.heroText}>
            <View style={styles.badge}>
              <Leaf color={COLORS.gold} size={14} strokeWidth={2.4} />
              <Text style={styles.badgeText}>{ECOQUEST.slogan}</Text>
            </View>
            <Text style={styles.heroTitle}>{ECOQUEST.name}</Text>
            <Text style={styles.heroTagline}>{ECOQUEST.tagline}</Text>
            <View style={styles.heroCtas}>
              <Pressable
                style={({ pressed }) => [styles.primaryCta, { opacity: pressed ? 0.9 : 1 }]}
                onPress={() => router.push('/solutions')}
              >
                <Text style={styles.primaryCtaText}>How it works</Text>
                <ArrowRight color={COLORS.heroDark} size={16} strokeWidth={2.6} />
              </Pressable>
              <Pressable
                style={({ pressed }) => [styles.secondaryCta, { opacity: pressed ? 0.85 : 1 }]}
                onPress={() => router.push('/catalog')}
              >
                <Text style={styles.secondaryCtaText}>Browse catalog</Text>
              </Pressable>
            </View>
          </View>
          <View style={styles.heroImageWrap}>
            <Image source={{ uri: ECOQUEST.heroTruck }} style={styles.heroImage} />
            <View style={styles.heroImageFrame} />
          </View>
        </View>
      </LinearGradient>

      {/* STATS */}
      <View style={styles.statsBar}>
        {STATS.map((s) => (
          <View key={s.label} style={styles.statItem}>
            <Text style={styles.statValue}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* FEATURES */}
      <View style={styles.section}>
        <SectionHeader
          center
          eyebrow="Why ECOQUEST"
          title="Cleaning up, made rewarding"
          subtitle="Every feature is built to turn picking up trash into a game you actually want to play."
        />
        <View style={styles.featureGrid}>
          {FEATURES.map((f) => {
            const Icon = FEATURE_ICONS[f.icon];
            return (
              <View key={f.title} style={styles.featureCard}>
                <View style={styles.featureIconWrap}>
                  <Icon color={COLORS.primary} size={24} strokeWidth={2.2} />
                </View>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureDesc}>{f.description}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* COMMUNITY BANNER */}
      <LinearGradient
        colors={[COLORS.surfaceLight, COLORS.bg]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.communityBanner}
      >
        <View style={styles.section}>
          <SectionHeader
            eyebrow="Real people, real impact"
            title="Neighbors cleaning up neighborhoods"
            subtitle="ECOQUEST heroes are out there every day, turning their communities into a winning game."
          />
        </View>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={[COMMUNITY_IMAGES.cleanup1, COMMUNITY_IMAGES.cleanup2, COMMUNITY_IMAGES.cleanup3, COMMUNITY_IMAGES.cleanup4, COMMUNITY_IMAGES.cleanup5]}
          keyExtractor={(uri, i) => `${i}`}
          contentContainerStyle={styles.galleryScroll}
          renderItem={({ item: uri }) => (
            <View style={styles.galleryCard}>
              <Image source={{ uri }} style={styles.galleryImage} />
            </View>
          )}
        />
      </LinearGradient>

      {/* CTA */}
      <View style={styles.section}>
        <LinearGradient
          colors={[COLORS.primary, COLORS.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.ctaCard}
        >
          <Text style={styles.ctaTitle}>Ready to become an Eco Hero?</Text>
          <Text style={styles.ctaSubtitle}>
            Join thousands of people getting paid to keep their communities clean.
          </Text>
          <Pressable
            style={({ pressed }) => [styles.ctaButton, { opacity: pressed ? 0.9 : 1 }]}
            onPress={() => router.push('/contact')}
          >
            <Text style={styles.ctaButtonText}>Get started today</Text>
            <ArrowRight color={COLORS.primary} size={16} strokeWidth={2.6} />
          </Pressable>
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  hero: { width: '100%' },
  heroInner: {
    maxWidth: 920,
    width: '100%',
    alignSelf: 'center',
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    justifyContent: 'center',
    gap: SPACING.xl,
    paddingHorizontal: SPACING.lg,
    paddingBottom: SPACING.xxxl,
    paddingTop: SPACING.xl,
  },
  heroText: { flex: 1, minWidth: 280, gap: SPACING.md },
  badge: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 6,
    alignSelf: 'flex-start',
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: RADIUS.pill,
    backgroundColor: 'rgba(255,255,255,0.1)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.18)',
  },
  badgeText: { fontFamily: FONTS.medium, fontSize: 12, color: COLORS.gold, letterSpacing: 0.3 },
  heroTitle: {
    fontFamily: FONTS.extraBold,
    fontSize: 56,
    lineHeight: 60,
    color: '#fff',
    letterSpacing: 1,
  },
  heroTagline: {
    fontFamily: FONTS.regular,
    fontSize: 17,
    lineHeight: 26,
    color: 'rgba(255,255,255,0.85)',
    maxWidth: 420,
  },
  heroCtas: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, marginTop: SPACING.sm },
  primaryCta: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    backgroundColor: COLORS.gold,
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.xl,
    borderRadius: RADIUS.pill,
    ...SHADOWS.button,
  },
  primaryCtaText: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.heroDark },
  secondaryCta: {
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.xl,
    borderRadius: RADIUS.pill,
    borderWidth: 1.5,
    borderColor: 'rgba(255,255,255,0.35)',
  },
  secondaryCtaText: { fontFamily: FONTS.bold, fontSize: 15, color: '#fff' },
  heroImageWrap: { width: 380, maxWidth: '100%', alignItems: 'center' },
  heroImage: {
    width: '100%',
    height: 240,
    borderRadius: RADIUS.lg,
    resizeMode: 'cover',
    ...SHADOWS.card,
  },
  heroImageFrame: {
    position: 'absolute',
    bottom: -10,
    left: 16,
    right: 16,
    height: 50,
    borderRadius: RADIUS.lg,
    backgroundColor: 'rgba(0,0,0,0.2)',
  },
  statsBar: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: SPACING.xl,
    paddingVertical: SPACING.xl,
    paddingHorizontal: SPACING.lg,
    backgroundColor: COLORS.surface,
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
    maxWidth: 920,
    width: '100%',
    alignSelf: 'center',
  },
  statItem: { alignItems: 'center', minWidth: 130 },
  statValue: { fontFamily: FONTS.extraBold, fontSize: 26, color: COLORS.primary },
  statLabel: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, marginTop: 2 },
  section: {
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.xxxl,
    maxWidth: 920,
    width: '100%',
    alignSelf: 'center',
    gap: SPACING.xl,
  },
  featureGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  featureCard: {
    backgroundColor: COLORS.card,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    padding: SPACING.lg,
    minWidth: 260,
    maxWidth: 300,
    flex: 1,
    gap: SPACING.sm,
    ...SHADOWS.soft,
  },
  featureIconWrap: {
    width: 48,
    height: 48,
    borderRadius: 14,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: COLORS.accentSoft,
  },
  featureTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.text },
  featureDesc: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 21, color: COLORS.textMuted },
  communityBanner: { paddingVertical: SPACING.xxxl, marginTop: SPACING.xxl },
  galleryScroll: { paddingHorizontal: SPACING.lg, gap: SPACING.md },
  galleryCard: {
    width: 280,
    height: 190,
    borderRadius: RADIUS.lg,
    overflow: 'hidden',
    marginRight: SPACING.md,
    ...SHADOWS.card,
  },
  galleryImage: { width: '100%', height: '100%', resizeMode: 'cover' },
  ctaCard: {
    borderRadius: RADIUS.xl,
    padding: SPACING.xxl,
    alignItems: 'center',
    gap: SPACING.md,
    ...SHADOWS.button,
  },
  ctaTitle: { fontFamily: FONTS.extraBold, fontSize: 26, color: '#fff', textAlign: 'center' },
  ctaSubtitle: { fontFamily: FONTS.regular, fontSize: 15, lineHeight: 23, color: 'rgba(255,255,255,0.9)', textAlign: 'center', maxWidth: 420 },
  ctaButton: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
    backgroundColor: '#fff',
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.xl,
    borderRadius: RADIUS.pill,
    marginTop: SPACING.xs,
  },
  ctaButtonText: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.primary },
});
