import { useEffect, useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, Image, FlatList, ActivityIndicator } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Coins, ShoppingBag, Sparkles } from 'lucide-react-native';
import { COLORS, FONTS, RADIUS, SPACING, SHADOWS } from '@/lib/theme';
import { CATALOG, type CatalogItem } from '@/lib/ecoquest-data';
import { SectionHeader } from '@/components/PageSection';
import { supabase } from '@/lib/supabase';

const CATEGORIES = ['All', 'Gear', 'Apparel'];

type DbCatalog = { name: string; description: string; price_coins: number; stock: number; image_url: string | null; category: string };

export default function CatalogScreen() {
  const insets = useSafeAreaInsets();
  const [items, setItems] = useState<CatalogItem[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [category, setCategory] = useState('All');

  useEffect(() => {
    let active = true;
    (async () => {
      setLoading(true);
      setError(null);
      try {
        const { data, error: dbError } = await supabase
          .from('catalog_items')
          .select('name, description, price_coins, stock, image_url, category')
          .order('price_coins', { ascending: true });

        if (!active) return;
        if (dbError) throw dbError;

        if (data && (data as DbCatalog[]).length > 0) {
          const mapped: CatalogItem[] = (data as DbCatalog[]).map((d) => ({
            name: d.name,
            description: d.description,
            priceCoins: d.price_coins,
            stock: d.stock,
            image: d.image_url ?? '',
            category: d.category,
          }));
          setItems(mapped);
        } else {
          setItems(CATALOG);
        }
      } catch (e) {
        if (!active) return;
        setError('We could not load the catalog right now. Please try again later.');
        setItems(CATALOG);
      } finally {
        if (active) setLoading(false);
      }
    })();
    return () => {
      active = false;
    };
  }, []);

  const filtered = category === 'All' ? items : items.filter((i) => i.category === category);

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxxl }}>
      <LinearGradient
        colors={[COLORS.heroDark, COLORS.heroGreen]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={{ height: insets.top }} />
        <View style={styles.headerInner}>
          <View style={styles.headerIconWrap}>
            <ShoppingBag color={COLORS.gold} size={26} strokeWidth={2.2} />
          </View>
          <Text style={styles.headerTitle}>Reward Catalog</Text>
          <Text style={styles.headerSubtitle}>
            Spend your ECO coins on eco-friendly gear and apparel. Every cleanup gets you closer to your next reward.
          </Text>
        </View>
      </LinearGradient>

      <View style={styles.section}>
        <View style={styles.filterRow}>
          {CATEGORIES.map((c) => {
            const active = category === c;
            return (
              <Pressable
                key={c}
                style={({ pressed }) => [
                  styles.filterChip,
                  active && styles.filterChipActive,
                  { opacity: pressed ? 0.85 : 1 },
                ]}
                onPress={() => setCategory(c)}
              >
                <Text style={[styles.filterChipText, active && styles.filterChipTextActive]}>{c}</Text>
              </Pressable>
            );
          })}
        </View>

        {loading ? (
          <View style={styles.loadingWrap}>
            <ActivityIndicator size="large" color={COLORS.primary} />
            <Text style={styles.loadingText}>Loading catalog...</Text>
          </View>
        ) : (
          <View style={styles.grid}>
            {filtered.map((item) => (
              <View key={item.name} style={styles.card}>
                <Image source={{ uri: item.image }} style={styles.cardImage} />
                <View style={styles.cardBody}>
                  <Text style={styles.cardCategory}>{item.category}</Text>
                  <Text style={styles.cardName}>{item.name}</Text>
                  <Text style={styles.cardDesc}>{item.description}</Text>
                  <View style={styles.cardFooter}>
                    <View style={styles.priceTag}>
                      <Coins color={COLORS.goldDeep} size={15} strokeWidth={2.4} />
                      <Text style={styles.priceText}>{item.priceCoins} coins</Text>
                    </View>
                    <Text style={styles.stockText}>{item.stock} in stock</Text>
                  </View>
                </View>
              </View>
            ))}
          </View>
        )}

        {error ? (
          <View style={styles.errorBanner}>
            <Text style={styles.errorText}>{error}</Text>
          </View>
        ) : null}
      </View>

      <View style={styles.section}>
        <LinearGradient
          colors={[COLORS.surfaceLight, COLORS.bg]}
          start={{ x: 0, y: 0 }}
          end={{ x: 0, y: 1 }}
          style={styles.earnCard}
        >
          <Sparkles color={COLORS.primary} size={22} strokeWidth={2.2} />
          <View style={styles.earnText}>
            <Text style={styles.earnTitle}>How do I earn coins?</Text>
            <Text style={styles.earnDesc}>
              Log verified cleanups to earn XP and ECO coins. The more trash you collect, the more you earn.
            </Text>
          </View>
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: { width: '100%' },
  headerInner: { alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xxl, paddingTop: SPACING.xl, gap: SPACING.sm },
  headerIconWrap: {
    width: 56,
    height: 56,
    borderRadius: 18,
    alignItems: 'center',
    justifyContent: 'center',
    backgroundColor: 'rgba(255,255,255,0.12)',
    borderWidth: 1,
    borderColor: 'rgba(255,255,255,0.2)',
  },
  headerTitle: { fontFamily: FONTS.extraBold, fontSize: 32, color: '#fff' },
  headerSubtitle: { fontFamily: FONTS.regular, fontSize: 15, lineHeight: 23, color: 'rgba(255,255,255,0.85)', textAlign: 'center', maxWidth: 480 },
  section: {
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.xxl,
    maxWidth: 920,
    width: '100%',
    alignSelf: 'center',
    gap: SPACING.lg,
  },
  filterRow: { flexDirection: 'row', gap: SPACING.sm, flexWrap: 'wrap' },
  filterChip: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: RADIUS.pill,
    borderWidth: 1.5,
    borderColor: COLORS.border,
    backgroundColor: COLORS.surface,
  },
  filterChipActive: { borderColor: COLORS.primary, backgroundColor: COLORS.accentSoft },
  filterChipText: { fontFamily: FONTS.medium, fontSize: 13, color: COLORS.textMuted },
  filterChipTextActive: { color: COLORS.primary },
  loadingWrap: { alignItems: 'center', justifyContent: 'center', paddingVertical: SPACING.xxxl, gap: SPACING.md },
  loadingText: { fontFamily: FONTS.regular, fontSize: 14, color: COLORS.textMuted },
  grid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  card: {
    backgroundColor: COLORS.card,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    borderColor: COLORS.cardBorder,
    overflow: 'hidden',
    minWidth: 260,
    maxWidth: 300,
    flex: 1,
    ...SHADOWS.soft,
  },
  cardImage: { width: '100%', height: 160, resizeMode: 'cover' },
  cardBody: { padding: SPACING.md, gap: 4 },
  cardCategory: { fontFamily: FONTS.medium, fontSize: 11, color: COLORS.primary, textTransform: 'uppercase', letterSpacing: 1 },
  cardName: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  cardDesc: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
  cardFooter: { flexDirection: 'row', alignItems: 'center', justifyContent: 'space-between', marginTop: SPACING.xs },
  priceTag: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(240,201,69,0.15)', paddingHorizontal: SPACING.sm, paddingVertical: 4, borderRadius: RADIUS.sm },
  priceText: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.goldDeep },
  stockText: { fontFamily: FONTS.regular, fontSize: 11, color: COLORS.textDim },
  errorBanner: { backgroundColor: 'rgba(214,69,69,0.1)', borderRadius: RADIUS.md, padding: SPACING.md, borderWidth: 1, borderColor: 'rgba(214,69,69,0.25)' },
  errorText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.danger, textAlign: 'center' },
  earnCard: { flexDirection: 'row', alignItems: 'center', gap: SPACING.md, borderRadius: RADIUS.lg, padding: SPACING.lg, borderWidth: 1, borderColor: COLORS.border },
  earnText: { flex: 1, gap: 4 },
  earnTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  earnDesc: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
});
