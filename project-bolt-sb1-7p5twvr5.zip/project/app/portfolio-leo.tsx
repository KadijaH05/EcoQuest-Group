import { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Image,
  Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FONTS, SPACING, RADIUS } from '@/lib/theme';

// Colors matching the screenshot — pure dark background, white/muted text
const C = {
  bg: '#0a0a0a',
  card: '#111111',
  border: '#252525',
  accent: '#ffffff',
  text: '#ffffff',
  textMuted: '#c8d0d8',
  textDim: '#5a6470',
  chipBg: 'rgba(255,255,255,0.06)',
  chipBorder: 'rgba(255,255,255,0.14)',
};

const INTERESTS = ['Music 🎧', 'Video Games 🎮', 'Basketball 🏀', 'Soccer ⚽', 'Watching Sports', 'Exploring'];

const FAVORITES = [
  { label: 'Artists', value: 'Playboi Carti, Ken Carson, Osamson' },
  { label: 'Games', value: 'Fortnite, Roblox' },
  { label: 'Sport', value: 'Basketball & Soccer' },
  { label: 'Soccer team', value: 'Arsenal FC' },
];

const AVATAR =
  'https://images.pexels.com/photos/6647255/pexels-photo-6647255.jpeg?auto=compress&cs=tinysrgb&w=400';

export default function PortfolioLeoScreen() {
  const insets = useSafeAreaInsets();
  const fade = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(20)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(slideUp, { toValue: 0, duration: 600, useNativeDriver: true }),
    ]).start();
  }, []);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxl }}
    >
      <View style={{ height: insets.top + SPACING.xl }} />

      {/* ── HERO ── */}
      <Animated.View
        style={[
          styles.heroSection,
          { opacity: fade, transform: [{ translateY: slideUp }] },
        ]}
      >
        <View style={styles.heroLayout}>
          {/* Left: name + intro text */}
          <View style={styles.introBlock}>
            <Text style={styles.name}>Destiny Dada</Text>
            <Text style={styles.introText}>
              {'Hello\u{1F90D} my name is Destiny i was born in Lagos Nigeria but i grew up in Newark New jersey i go the Newark school of Data science information Technology I am a rising  senior class of 2027 I have a lot of hobbies like listening to music\u{1F3A7} and playing video games and watching and playing sport my favorite artist is Playboi Carti,ken Carson and Osamson my favorite game \u{1F3AE} is Frotnite and Roblox my favorite sport \u{1F3C6} is basketball \u{1F3C0} and soccer \u26BD my favorite soccer team is Arsenal Fc. I also like exploring and trying new things.'}
            </Text>
          </View>

          {/* Right: circular avatar */}
          <View style={styles.avatarWrap}>
            <Image source={{ uri: AVATAR }} style={styles.avatarImage} resizeMode="cover" />
          </View>
        </View>
      </Animated.View>

      {/* ── DIVIDER ── */}
      <View style={styles.divider} />

      {/* ── INTERESTS ── */}
      <Animated.View style={[styles.section, { opacity: fade }]}>
        <Text style={styles.sectionLabel}>Interests</Text>
        <View style={styles.chipRow}>
          {INTERESTS.map((i) => (
            <View key={i} style={styles.chip}>
              <Text style={styles.chipText}>{i}</Text>
            </View>
          ))}
        </View>
      </Animated.View>

      {/* ── FAVORITES ── */}
      <Animated.View style={[styles.section, { opacity: fade }]}>
        <Text style={styles.sectionLabel}>Favorites</Text>
        <View style={styles.favGrid}>
          {FAVORITES.map((f) => (
            <View key={f.label} style={styles.favCard}>
              <Text style={styles.favLabel}>{f.label}</Text>
              <Text style={styles.favValue}>{f.value}</Text>
            </View>
          ))}
        </View>
      </Animated.View>

      {/* ── ABOUT ── */}
      <Animated.View style={[styles.section, { opacity: fade }]}>
        <Text style={styles.sectionLabel}>About Me</Text>
        <View style={styles.aboutCard}>
          <View style={styles.aboutAccent} />
          <Text style={styles.aboutText}>
            Born in Lagos, Nigeria and raised in Newark, New Jersey, Destiny brings a global perspective to everything she does. She is a rising senior at the Newark School of Data Science & Information Technology, class of 2027, with a passion for sports, music, and exploring new things.
          </Text>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bg,
  },

  /* HERO */
  heroSection: {
    paddingHorizontal: SPACING.xl,
    maxWidth: 960,
    width: '100%',
    alignSelf: 'center',
  },
  heroLayout: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: SPACING.xxl,
    justifyContent: 'space-between',
  },
  introBlock: {
    flex: 1,
    minWidth: 280,
    maxWidth: 580,
    gap: SPACING.lg,
  },
  name: {
    fontFamily: FONTS.extraBold,
    fontSize: 42,
    color: C.text,
    lineHeight: 48,
    letterSpacing: -0.5,
  },
  introText: {
    fontFamily: 'monospace',
    fontSize: 13.5,
    lineHeight: 24,
    color: C.textMuted,
  },

  /* Avatar */
  avatarWrap: {
    width: 220,
    height: 220,
    borderRadius: 110,
    overflow: 'hidden',
    borderWidth: 2,
    borderColor: 'rgba(255,255,255,0.15)',
    backgroundColor: '#1a1a1a',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },

  divider: {
    height: 1,
    backgroundColor: C.border,
    marginHorizontal: SPACING.xl,
    marginTop: SPACING.xxl,
    maxWidth: 960,
    width: '100%' ,
    alignSelf: 'center',
  },

  /* SECTIONS */
  section: {
    paddingHorizontal: SPACING.xl,
    paddingTop: SPACING.xxl,
    maxWidth: 960,
    width: '100%',
    alignSelf: 'center',
    gap: SPACING.md,
  },
  sectionLabel: {
    fontFamily: FONTS.bold,
    fontSize: 12,
    color: C.textDim,
    textTransform: 'uppercase',
    letterSpacing: 2,
  },

  /* Chips */
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  chip: {
    backgroundColor: C.chipBg,
    borderWidth: 1,
    borderColor: C.chipBorder,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs + 2,
    borderRadius: RADIUS.pill,
  },
  chipText: {
    fontFamily: FONTS.medium,
    fontSize: 13,
    color: C.textMuted,
  },

  /* Favorites */
  favGrid: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  favCard: {
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: RADIUS.md,
    padding: SPACING.md,
    minWidth: 180,
    flex: 1,
    gap: 4,
  },
  favLabel: {
    fontFamily: FONTS.medium,
    fontSize: 11,
    color: C.textDim,
    textTransform: 'uppercase',
    letterSpacing: 1,
  },
  favValue: {
    fontFamily: FONTS.semiBold,
    fontSize: 14,
    color: C.text,
  },

  /* About */
  aboutCard: {
    flexDirection: 'row',
    gap: SPACING.md,
    backgroundColor: C.card,
    borderWidth: 1,
    borderColor: C.border,
    borderRadius: RADIUS.lg,
    padding: SPACING.lg,
  },
  aboutAccent: {
    width: 3,
    borderRadius: 2,
    backgroundColor: '#ffffff',
    minHeight: 40,
  },
  aboutText: {
    flex: 1,
    fontFamily: FONTS.regular,
    fontSize: 14,
    lineHeight: 23,
    color: C.textMuted,
  },
});
