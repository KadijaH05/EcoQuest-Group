import { View, Text, StyleSheet, ScrollView, Image, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Quote, Heart, Users, MapPin } from 'lucide-react-native';
import { COLORS, FONTS, RADIUS, SPACING, SHADOWS } from '@/lib/theme';
import { TESTIMONIALS, COMMUNITY_IMAGES, STATS } from '@/lib/ecoquest-data';
import { SectionHeader } from '@/components/PageSection';

const STORIES = [
  { image: COMMUNITY_IMAGES.cleanup1, title: 'Oakland Park Revival', location: 'Oakland, CA', text: 'A team of 24 volunteers cleared 1,200 items from Lakeside Park in a single weekend.' },
  { image: COMMUNITY_IMAGES.cleanup2, title: 'One Hero, One Park', location: 'Austin, TX', text: 'Marcus earned the Neighborhood Hero badge after cleaning 5 different parks solo.' },
  { image: COMMUNITY_IMAGES.cleanup3, title: 'Forest Restoration Day', location: 'Portland, OR', text: 'ECOQUEST heroes filled 38 bags of trash from Forest Park trails in one day.' },
  { image: COMMUNITY_IMAGES.cleanup6, title: 'Riverbank Rescue', location: 'Seattle, WA', text: 'A community group removed 600 pounds of litter from the Green River banks.' },
];

export default function CustomersScreen() {
  const insets = useSafeAreaInsets();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxxl }}>
      <LinearGradient
        colors={[COLORS.heroDark, COLORS.heroGreen]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={{ height: insets.top }} />
        <View style={styles.headerInner}>
          <View style={styles.headerIconWrap}>
            <Users color={COLORS.gold} size={26} strokeWidth={2.2} />
          </View>
          <Text style={styles.headerTitle}>Our Community</Text>
          <Text style={styles.headerSubtitle}>
            Real stories from the eco-heroes turning their neighborhoods into a winning game.
          </Text>
        </View>
      </LinearGradient>

      {/* STATS */}
      <View style={styles.statsBar}>
        {STATS.map((s) => (
          <View key={s.label} style={styles.statItem}>
            <Text style={styles.statValue}>{s.value}</Text>
            <Text style={styles.statLabel}>{s.label}</Text>
          </View>
        ))}
      </View>

      {/* TESTIMONIALS */}
      <View style={styles.section}>
        <SectionHeader center eyebrow="Voices from the field" title="What our heroes say" />
        <View style={styles.testimonialGrid}>
          {TESTIMONIALS.map((t) => (
            <View key={t.name} style={styles.testimonialCard}>
              <Quote color={COLORS.accent} size={28} strokeWidth={2} />
              <Text style={styles.testimonialQuote}>{t.quote}</Text>
              <View style={styles.testimonialFooter}>
                <Image source={{ uri: t.avatar }} style={styles.testimonialAvatar} />
                <View>
                  <Text style={styles.testimonialName}>{t.name}</Text>
                  <Text style={styles.testimonialRole}>{t.role}</Text>
                </View>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* COMMUNITY STORIES */}
      <LinearGradient
        colors={[COLORS.surfaceLight, COLORS.bg]}
        start={{ x: 0, y: 0 }}
        end={{ x: 0, y: 1 }}
        style={styles.storiesBanner}
      >
        <View style={styles.section}>
          <SectionHeader eyebrow="Cleanup stories" title="Neighborhoods getting cleaner" subtitle="Every photo is a verified cleanup logged through ECOQUEST." />
        </View>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={STORIES}
          keyExtractor={(item) => item.title}
          contentContainerStyle={styles.storiesScroll}
          renderItem={({ item }) => (
            <View style={styles.storyCard}>
              <Image source={{ uri: item.image }} style={styles.storyImage} />
              <View style={styles.storyBody}>
                <View style={styles.storyLocation}>
                  <MapPin color={COLORS.primary} size={12} strokeWidth={2.4} />
                  <Text style={styles.storyLocationText}>{item.location}</Text>
                </View>
                <Text style={styles.storyTitle}>{item.title}</Text>
                <Text style={styles.storyText}>{item.text}</Text>
              </View>
            </View>
          )}
        />
      </LinearGradient>

      {/* JOIN CTA */}
      <View style={styles.section}>
        <View style={styles.joinCard}>
          <Heart color={COLORS.primary} size={22} strokeWidth={2.2} />
          <Text style={styles.joinTitle}>Join the movement</Text>
          <Text style={styles.joinText}>
            Be part of a community that is measurably cleaning up the planet, one block at a time.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: { width: '100%' },
  headerInner: { alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xxl, paddingTop: SPACING.xl, gap: SPACING.sm },
  headerIconWrap: { width: 56, height: 56, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  headerTitle: { fontFamily: FONTS.extraBold, fontSize: 32, color: '#fff' },
  headerSubtitle: { fontFamily: FONTS.regular, fontSize: 15, lineHeight: 23, color: 'rgba(255,255,255,0.85)', textAlign: 'center', maxWidth: 480 },
  statsBar: { flexDirection: 'row', flexWrap: 'wrap', justifyContent: 'center', gap: SPACING.xl, paddingVertical: SPACING.xl, paddingHorizontal: SPACING.lg, backgroundColor: COLORS.surface, borderBottomWidth: 1, borderBottomColor: COLORS.border, maxWidth: 920, width: '100%', alignSelf: 'center' },
  statItem: { alignItems: 'center', minWidth: 130 },
  statValue: { fontFamily: FONTS.extraBold, fontSize: 26, color: COLORS.primary },
  statLabel: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, marginTop: 2 },
  section: { paddingHorizontal: SPACING.lg, paddingTop: SPACING.xxxl, maxWidth: 920, width: '100%', alignSelf: 'center', gap: SPACING.xl },
  testimonialGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  testimonialCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.lg, minWidth: 280, maxWidth: 340, flex: 1, gap: SPACING.sm, ...SHADOWS.soft },
  testimonialQuote: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: COLORS.textMuted, fontStyle: 'italic' },
  testimonialFooter: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, marginTop: SPACING.xs },
  testimonialAvatar: { width: 40, height: 40, borderRadius: 20, resizeMode: 'cover' },
  testimonialName: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.text },
  testimonialRole: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textDim },
  storiesBanner: { paddingVertical: SPACING.xxxl, marginTop: SPACING.xxl },
  storiesScroll: { paddingHorizontal: SPACING.lg },
  storyCard: { width: 300, marginRight: SPACING.md, borderRadius: RADIUS.lg, overflow: 'hidden', backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.cardBorder, ...SHADOWS.card },
  storyImage: { width: '100%', height: 180, resizeMode: 'cover' },
  storyBody: { padding: SPACING.md, gap: 4 },
  storyLocation: { flexDirection: 'row', alignItems: 'center', gap: 4 },
  storyLocationText: { fontFamily: FONTS.medium, fontSize: 11, color: COLORS.primary },
  storyTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  storyText: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
  joinCard: { alignItems: 'center', gap: SPACING.sm, backgroundColor: COLORS.card, borderRadius: RADIUS.xl, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.xxl, ...SHADOWS.soft },
  joinTitle: { fontFamily: FONTS.bold, fontSize: 20, color: COLORS.text },
  joinText: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: COLORS.textMuted, textAlign: 'center', maxWidth: 400 },
});
