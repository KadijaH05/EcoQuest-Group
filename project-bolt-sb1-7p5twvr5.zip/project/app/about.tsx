import { View, Text, StyleSheet, ScrollView, Pressable, Image } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Leaf, Users, Trophy, Shield, ArrowRight, Sparkles } from 'lucide-react-native';
import { router } from 'expo-router';
import { COLORS, FONTS, RADIUS, SPACING, SHADOWS } from '@/lib/theme';
import { COMPANY, ECOQUEST, COMMUNITY_IMAGES } from '@/lib/ecoquest-data';
import { SectionHeader } from '@/components/PageSection';

const VALUE_ICONS = { leaf: Leaf, users: Users, trophy: Trophy, shield: Shield };

export default function AboutScreen() {
  const insets = useSafeAreaInsets();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxxl }}>
      <LinearGradient
        colors={[COLORS.heroDark, COLORS.heroGreen]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={{ height: insets.top }} />
        <View style={styles.headerInner}>
          <View style={styles.headerIconWrap}>
            <Leaf color={COLORS.gold} size={26} strokeWidth={2.2} />
          </View>
          <Text style={styles.headerTitle}>About ECOQUEST</Text>
          <Text style={styles.headerSubtitle}>{ECOQUEST.slogan}</Text>
        </View>
      </LinearGradient>

      {/* MISSION */}
      <View style={styles.section}>
        <SectionHeader eyebrow="Our mission" title="Paying people to clean up the planet" />
        <Text style={styles.missionText}>{COMPANY.mission}</Text>
        <Image source={{ uri: COMMUNITY_IMAGES.group }} style={styles.missionImage} />
      </View>

      {/* STORY */}
      <View style={[styles.section, styles.altBg]}>
        <SectionHeader eyebrow="How we started" title="From a littered park to a movement" />
        <Text style={styles.storyText}>{COMPANY.story}</Text>
        <View style={styles.foundedBadge}>
          <Sparkles color={COLORS.goldDeep} size={16} strokeWidth={2.4} />
          <Text style={styles.foundedText}>Founded in {COMPANY.founded}</Text>
        </View>
      </View>

      {/* VALUES */}
      <View style={styles.section}>
        <SectionHeader center eyebrow="What we believe" title="Our core values" />
        <View style={styles.valuesGrid}>
          {COMPANY.values.map((v) => {
            const Icon = VALUE_ICONS[v.icon];
            return (
              <View key={v.title} style={styles.valueCard}>
                <View style={styles.valueIconWrap}>
                  <Icon color={COLORS.primary} size={22} strokeWidth={2.2} />
                </View>
                <Text style={styles.valueTitle}>{v.title}</Text>
                <Text style={styles.valueDesc}>{v.description}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* TEAM */}
      <View style={[styles.section, styles.altBg]}>
        <SectionHeader center eyebrow="The founders" title="Meet the team behind ECOQUEST" subtitle="Two creators who turned a littered park into a gamified cleanup movement." />
        <View style={styles.teamGrid}>
          {COMPANY.team.map((member) => (
            <Pressable
              key={member.name}
              style={({ pressed }) => [styles.teamCard, { opacity: pressed ? 0.92 : 1 }]}
              onPress={() => router.push(member.href as any)}
            >
              <View style={styles.teamAvatarWrap}>
                <Leaf color={COLORS.primary} size={20} strokeWidth={2.2} />
              </View>
              <Text style={styles.teamName}>{member.name}</Text>
              <Text style={styles.teamRole}>{member.role}</Text>
              <View style={styles.teamLink}>
                <Text style={styles.teamLinkText}>View portfolio</Text>
                <ArrowRight color={COLORS.primary} size={13} strokeWidth={2.6} />
              </View>
            </Pressable>
          ))}
        </View>
      </View>

      {/* CTA */}
      <View style={styles.section}>
        <LinearGradient
          colors={[COLORS.primary, COLORS.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.ctaCard}
        >
          <Text style={styles.ctaTitle}>Want to bring ECOQUEST to your city?</Text>
          <Text style={styles.ctaSubtitle}>We partner with communities and cities to launch local cleanup programs.</Text>
          <Pressable
            style={({ pressed }) => [styles.ctaButton, { opacity: pressed ? 0.9 : 1 }]}
            onPress={() => router.push('/contact')}
          >
            <Text style={styles.ctaButtonText}>Get in touch</Text>
            <ArrowRight color={COLORS.primary} size={16} strokeWidth={2.6} />
          </Pressable>
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: { width: '100%' },
  headerInner: { alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xxl, paddingTop: SPACING.xl, gap: SPACING.sm },
  headerIconWrap: { width: 56, height: 56, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  headerTitle: { fontFamily: FONTS.extraBold, fontSize: 32, color: '#fff' },
  headerSubtitle: { fontFamily: FONTS.regular, fontSize: 15, color: 'rgba(255,255,255,0.85)', textAlign: 'center', maxWidth: 480 },
  section: { paddingHorizontal: SPACING.lg, paddingTop: SPACING.xxxl, maxWidth: 920, width: '100%', alignSelf: 'center', gap: SPACING.lg },
  altBg: { backgroundColor: COLORS.surfaceLight, width: '100%', alignSelf: 'stretch', paddingHorizontal: SPACING.lg, paddingVertical: SPACING.xxxl },
  missionText: { fontFamily: FONTS.regular, fontSize: 16, lineHeight: 26, color: COLORS.textMuted },
  missionImage: { width: '100%', height: 240, borderRadius: RADIUS.lg, resizeMode: 'cover', ...SHADOWS.card },
  storyText: { fontFamily: FONTS.regular, fontSize: 15, lineHeight: 24, color: COLORS.textMuted },
  foundedBadge: { flexDirection: 'row', alignItems: 'center', gap: 6, alignSelf: 'flex-start', backgroundColor: 'rgba(240,201,69,0.15)', paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderRadius: RADIUS.pill },
  foundedText: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.goldDeep },
  valuesGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  valueCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.lg, minWidth: 240, maxWidth: 280, flex: 1, gap: SPACING.sm, ...SHADOWS.soft },
  valueIconWrap: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.accentSoft },
  valueTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  valueDesc: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
  teamGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  teamCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.xl, minWidth: 260, maxWidth: 320, flex: 1, alignItems: 'center', gap: SPACING.sm, ...SHADOWS.soft },
  teamAvatarWrap: { width: 56, height: 56, borderRadius: 28, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.accentSoft },
  teamName: { fontFamily: FONTS.bold, fontSize: 18, color: COLORS.text },
  teamRole: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.textMuted, textAlign: 'center' },
  teamLink: { flexDirection: 'row', alignItems: 'center', gap: 4, marginTop: SPACING.xs },
  teamLinkText: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.primary },
  ctaCard: { borderRadius: RADIUS.xl, padding: SPACING.xxl, alignItems: 'center', gap: SPACING.md, ...SHADOWS.button },
  ctaTitle: { fontFamily: FONTS.extraBold, fontSize: 24, color: '#fff', textAlign: 'center' },
  ctaSubtitle: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: 'rgba(255,255,255,0.9)', textAlign: 'center', maxWidth: 400 },
  ctaButton: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm, backgroundColor: '#fff', paddingVertical: SPACING.md, paddingHorizontal: SPACING.xl, borderRadius: RADIUS.pill, marginTop: SPACING.xs },
  ctaButtonText: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.primary },
});
