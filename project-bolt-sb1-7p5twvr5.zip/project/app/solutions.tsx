import { View, Text, StyleSheet, ScrollView, Pressable } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import {
  Camera,
  MapPin,
  Award,
  Trophy,
  Recycle,
  Users,
  Check,
  Sparkles,
  Wrench,
} from 'lucide-react-native';
import { router } from 'expo-router';
import { COLORS, FONTS, RADIUS, SPACING, SHADOWS } from '@/lib/theme';
import { STEPS, BADGES, SOLUTIONS, FEATURES } from '@/lib/ecoquest-data';
import { SectionHeader } from '@/components/PageSection';

const FEATURE_ICONS = { camera: Camera, map: MapPin, award: Award, trophy: Trophy, recycle: Recycle, users: Users };

export default function SolutionsScreen() {
  const insets = useSafeAreaInsets();

  return (
    <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxxl }}>
      <LinearGradient
        colors={[COLORS.heroDark, COLORS.heroGreen]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.header}
      >
        <View style={{ height: insets.top }} />
        <View style={styles.headerInner}>
          <View style={styles.headerIconWrap}>
            <Wrench color={COLORS.gold} size={26} strokeWidth={2.2} />
          </View>
          <Text style={styles.headerTitle}>How ECOQUEST Works</Text>
          <Text style={styles.headerSubtitle}>
            From spotting trash to spending rewards, here is the full cleanup journey.
          </Text>
        </View>
      </LinearGradient>

      {/* STEPS */}
      <View style={styles.section}>
        <SectionHeader center eyebrow="The flow" title="Four steps to a cleaner block" />
        <View style={styles.stepsWrap}>
          {STEPS.map((step, i) => (
            <View key={step.num} style={styles.stepRow}>
              <View style={styles.stepNumWrap}>
                <Text style={styles.stepNum}>{step.num}</Text>
              </View>
              <View style={styles.stepBody}>
                <Text style={styles.stepTitle}>{step.title}</Text>
                <Text style={styles.stepDesc}>{step.description}</Text>
              </View>
              {i < STEPS.length - 1 ? <View style={styles.stepConnector} /> : null}
            </View>
          ))}
        </View>
      </View>

      {/* TECH FEATURES */}
      <View style={[styles.section, styles.altBg]}>
        <SectionHeader center eyebrow="The technology" title="Features that power the game" />
        <View style={styles.featureGrid}>
          {FEATURES.map((f) => {
            const Icon = FEATURE_ICONS[f.icon];
            return (
              <View key={f.title} style={styles.featureCard}>
                <View style={styles.featureIconWrap}>
                  <Icon color={COLORS.primary} size={22} strokeWidth={2.2} />
                </View>
                <Text style={styles.featureTitle}>{f.title}</Text>
                <Text style={styles.featureDesc}>{f.description}</Text>
              </View>
            );
          })}
        </View>
      </View>

      {/* BADGES */}
      <View style={styles.section}>
        <SectionHeader center eyebrow="Gameplay" title="Earn XP and unlock badges" subtitle="Every milestone is a badge waiting to be earned. Climb from Rookie to Eco Legend." />
        <View style={styles.badgeGrid}>
          {BADGES.map((b) => (
            <View key={b.name} style={styles.badgeCard}>
              <Text style={styles.badgeEmoji}>{b.emoji}</Text>
              <Text style={styles.badgeName}>{b.name}</Text>
              <Text style={styles.badgeDesc}>{b.description}</Text>
              <View style={styles.badgeXp}>
                <Sparkles color={COLORS.goldDeep} size={12} strokeWidth={2.4} />
                <Text style={styles.badgeXpText}>{b.xp} XP</Text>
              </View>
            </View>
          ))}
        </View>
      </View>

      {/* SOLUTIONS FOR AUDIENCES */}
      <View style={[styles.section, styles.altBg]}>
        <SectionHeader center eyebrow="Who it is for" title="Solutions for everyone" />
        <View style={styles.solutionsGrid}>
          {SOLUTIONS.map((sol) => (
            <View key={sol.title} style={styles.solutionCard}>
              <Text style={styles.solutionTitle}>{sol.title}</Text>
              {sol.points.map((p) => (
                <View key={p} style={styles.solutionPoint}>
                  <View style={styles.checkDot}>
                    <Check color="#fff" size={12} strokeWidth={3} />
                  </View>
                  <Text style={styles.solutionPointText}>{p}</Text>
                </View>
              ))}
            </View>
          ))}
        </View>
      </View>

      {/* CTA */}
      <View style={styles.section}>
        <LinearGradient
          colors={[COLORS.primary, COLORS.accent]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.ctaCard}
        >
          <Text style={styles.ctaTitle}>See it in action</Text>
          <Text style={styles.ctaSubtitle}>Browse the reward catalog or reach out to bring ECOQUEST to your city.</Text>
          <View style={styles.ctaRow}>
            <Pressable
              style={({ pressed }) => [styles.ctaButton, { opacity: pressed ? 0.9 : 1 }]}
              onPress={() => router.push('/catalog')}
            >
              <Text style={styles.ctaButtonText}>View catalog</Text>
            </Pressable>
            <Pressable
              style={({ pressed }) => [styles.ctaButtonGhost, { opacity: pressed ? 0.85 : 1 }]}
              onPress={() => router.push('/contact')}
            >
              <Text style={styles.ctaButtonGhostText}>Contact us</Text>
            </Pressable>
          </View>
        </LinearGradient>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: { width: '100%' },
  headerInner: { alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xxl, paddingTop: SPACING.xl, gap: SPACING.sm },
  headerIconWrap: { width: 56, height: 56, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  headerTitle: { fontFamily: FONTS.extraBold, fontSize: 32, color: '#fff' },
  headerSubtitle: { fontFamily: FONTS.regular, fontSize: 15, lineHeight: 23, color: 'rgba(255,255,255,0.85)', textAlign: 'center', maxWidth: 480 },
  section: { paddingHorizontal: SPACING.lg, paddingTop: SPACING.xxxl, maxWidth: 920, width: '100%', alignSelf: 'center', gap: SPACING.xl },
  altBg: { backgroundColor: COLORS.surfaceLight, marginHorizontal: 0, paddingVertical: SPACING.xxxl, width: '100%', paddingHorizontal: SPACING.lg, alignSelf: 'stretch' },
  stepsWrap: { gap: SPACING.sm },
  stepRow: { flexDirection: 'row', gap: SPACING.md, backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.lg, ...SHADOWS.soft },
  stepNumWrap: { width: 44, height: 44, borderRadius: 22, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.primary },
  stepNum: { fontFamily: FONTS.extraBold, fontSize: 16, color: '#fff' },
  stepBody: { flex: 1, gap: 4 },
  stepTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.text },
  stepDesc: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: COLORS.textMuted },
  stepConnector: { position: 'absolute', left: SPACING.lg + 22, top: SPACING.lg + 44, width: 2, bottom: -SPACING.sm, backgroundColor: COLORS.border },
  featureGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  featureCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.lg, minWidth: 260, maxWidth: 300, flex: 1, gap: SPACING.sm, ...SHADOWS.soft },
  featureIconWrap: { width: 44, height: 44, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.accentSoft },
  featureTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  featureDesc: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
  badgeGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  badgeCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.lg, minWidth: 200, maxWidth: 240, flex: 1, alignItems: 'center', gap: 6, ...SHADOWS.soft },
  badgeEmoji: { fontSize: 36 },
  badgeName: { fontFamily: FONTS.bold, fontSize: 15, color: COLORS.text, textAlign: 'center' },
  badgeDesc: { fontFamily: FONTS.regular, fontSize: 12, lineHeight: 18, color: COLORS.textMuted, textAlign: 'center' },
  badgeXp: { flexDirection: 'row', alignItems: 'center', gap: 4, backgroundColor: 'rgba(240,201,69,0.15)', paddingHorizontal: SPACING.sm, paddingVertical: 3, borderRadius: RADIUS.sm, marginTop: 4 },
  badgeXpText: { fontFamily: FONTS.bold, fontSize: 12, color: COLORS.goldDeep },
  solutionsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  solutionCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.lg, minWidth: 260, maxWidth: 300, flex: 1, gap: SPACING.sm, ...SHADOWS.soft },
  solutionTitle: { fontFamily: FONTS.bold, fontSize: 17, color: COLORS.primary, marginBottom: SPACING.xs },
  solutionPoint: { flexDirection: 'row', alignItems: 'flex-start', gap: SPACING.sm },
  checkDot: { width: 18, height: 18, borderRadius: 9, backgroundColor: COLORS.primary, alignItems: 'center', justifyContent: 'center', marginTop: 2 },
  solutionPointText: { flex: 1, fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
  ctaCard: { borderRadius: RADIUS.xl, padding: SPACING.xxl, alignItems: 'center', gap: SPACING.md, ...SHADOWS.button },
  ctaTitle: { fontFamily: FONTS.extraBold, fontSize: 24, color: '#fff', textAlign: 'center' },
  ctaSubtitle: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: 'rgba(255,255,255,0.9)', textAlign: 'center', maxWidth: 400 },
  ctaRow: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center', marginTop: SPACING.xs },
  ctaButton: { backgroundColor: '#fff', paddingVertical: SPACING.md, paddingHorizontal: SPACING.xl, borderRadius: RADIUS.pill },
  ctaButtonText: { fontFamily: FONTS.bold, fontSize: 14, color: COLORS.primary },
  ctaButtonGhost: { paddingVertical: SPACING.md, paddingHorizontal: SPACING.xl, borderRadius: RADIUS.pill, borderWidth: 1.5, borderColor: 'rgba(255,255,255,0.4)' },
  ctaButtonGhostText: { fontFamily: FONTS.bold, fontSize: 14, color: '#fff' },
});
