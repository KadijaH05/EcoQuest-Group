import { useEffect, useRef } from 'react';
import {
  View,
  Text,
  StyleSheet,
  ScrollView,
  Pressable,
  Image,
  Animated,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { FONTS, SPACING, RADIUS } from '@/lib/theme';

const TOOL_LOGOS = [
  { label: 'ClickUp', text: '✦ ClickUp' },
  { label: 'Dropbox', text: '❏ Dropbox' },
  { label: 'PAYCHEX', text: 'PAYCHEX' },
  { label: 'elastic', text: '⬡ elastic' },
  { label: 'stripe', text: 'stripe' },
];

const INTERESTS = [
  'Music', 'Movies & Shows', 'Soccer', 'Basketball', 'Family & Friends',
];

const GOALS = [
  'Bilingual — fluent in 2 languages',
  'Aspiring medical professional',
  'Strong listener & quick learner',
  'Rising junior with big ambitions',
];

// Colors matching the screenshot dark/blue theme
const C = {
  bg: '#0d0d0d',
  card: '#111111',
  cardBorder: '#1e6fb0',
  accent: '#1a7fd4',
  accentSoft: 'rgba(26,127,212,0.15)',
  text: '#ffffff',
  textMuted: '#b0c4d8',
  textDim: '#6b7f90',
  toolBg: '#1a1a1a',
  toolBorder: '#2a2a2a',
  chipBg: 'rgba(26,127,212,0.12)',
  chipBorder: 'rgba(26,127,212,0.35)',
};

export default function PortfolioMayaScreen() {
  const insets = useSafeAreaInsets();
  const fade = useRef(new Animated.Value(0)).current;
  const slideUp = useRef(new Animated.Value(24)).current;

  useEffect(() => {
    Animated.parallel([
      Animated.timing(fade, { toValue: 1, duration: 600, useNativeDriver: true }),
      Animated.timing(slideUp, { toValue: 0, duration: 600, useNativeDriver: true }),
    ]).start();
  }, []);

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxl }}
    >
      <View style={{ height: insets.top }} />

      {/* ── HERO SECTION ── */}
      <Animated.View style={[styles.heroSection, { opacity: fade, transform: [{ translateY: slideUp }] }]}>
        <View style={styles.heroLayout}>
          {/* Left: intro card with dashed blue border */}
          <View style={styles.introCard}>
            <Text style={styles.name}>Kadija Hien</Text>
            <Text style={styles.introText}>
              Hello{'\u{1F44B}'}, My name is Kadija Hien, I&apos;m 15 years old. I&apos;m a rising junior. I&apos;m a very good listener and I like learning new things. I speak 2 languages and I like listening to music, watching movies/shows, soccer, basketball and hanging out with family and friends. I want to have a career in the medical field in the future, although I don&apos;t know what I want to be specifically, however, I have an idea.
            </Text>
            <Pressable
              style={({ pressed }) => [styles.ctaBtn, { opacity: pressed ? 0.88 : 1 }]}
            >
              <Text style={styles.ctaBtnText}>Let&apos;s get started &gt;</Text>
            </Pressable>
          </View>

          {/* Right: avatar circle */}
          <View style={styles.avatarWrap}>
            <Image
              source={require('@/assets/images/kadija-avatar.png')}
              style={styles.avatarImage}
              resizeMode="cover"
            />
          </View>
        </View>
      </Animated.View>

      {/* ── TOOL LOGOS BAR ── */}
      <Animated.View style={[styles.toolsBar, { opacity: fade }]}>
        {TOOL_LOGOS.map((t) => (
          <View key={t.label} style={styles.toolChip}>
            <Text style={styles.toolText}>{t.text}</Text>
          </View>
        ))}
      </Animated.View>

      {/* ── ABOUT DETAILS ── */}
      <View style={styles.detailsSection}>
        {/* Interests */}
        <View style={styles.detailCard}>
          <Text style={styles.detailHeading}>Interests</Text>
          <View style={styles.chipRow}>
            {INTERESTS.map((i) => (
              <View key={i} style={styles.interestChip}>
                <Text style={styles.interestChipText}>{i}</Text>
              </View>
            ))}
          </View>
        </View>

        {/* About me bullets */}
        <View style={styles.detailCard}>
          <Text style={styles.detailHeading}>About Me</Text>
          {GOALS.map((g) => (
            <View key={g} style={styles.bulletRow}>
              <View style={styles.bullet} />
              <Text style={styles.bulletText}>{g}</Text>
            </View>
          ))}
        </View>

        {/* Future goals */}
        <View style={[styles.detailCard, styles.goalCard]}>
          <Text style={styles.detailHeading}>Future Goals</Text>
          <Text style={styles.goalText}>
            My goal is to pursue a career in the medical field. I may not know my exact specialty yet, but I&apos;m driven, curious, and ready to find out. Every step I take today is one step closer to helping people tomorrow.
          </Text>
        </View>
      </View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: C.bg,
  },

  /* HERO */
  heroSection: {
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.xl,
    maxWidth: 960,
    width: '100%',
    alignSelf: 'center',
  },
  heroLayout: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    alignItems: 'center',
    gap: SPACING.xl,
    justifyContent: 'center',
  },

  /* Intro card — dashed blue border matching screenshot */
  introCard: {
    flex: 1,
    minWidth: 280,
    maxWidth: 540,
    borderWidth: 1.5,
    borderColor: C.cardBorder,
    borderRadius: RADIUS.md,
    borderStyle: 'dashed',
    padding: SPACING.xl,
    gap: SPACING.md,
    backgroundColor: 'rgba(26,127,212,0.04)',
  },
  name: {
    fontFamily: FONTS.extraBold,
    fontSize: 36,
    color: C.text,
    lineHeight: 42,
  },
  introText: {
    fontFamily: 'monospace',
    fontSize: 13,
    lineHeight: 22,
    color: C.textMuted,
  },
  ctaBtn: {
    alignSelf: 'flex-start',
    backgroundColor: C.accent,
    paddingVertical: SPACING.md,
    paddingHorizontal: SPACING.xl,
    borderRadius: RADIUS.sm,
    marginTop: SPACING.xs,
  },
  ctaBtnText: {
    fontFamily: FONTS.bold,
    fontSize: 14,
    color: '#fff',
    letterSpacing: 0.3,
  },

  /* Avatar */
  avatarWrap: {
    width: 200,
    height: 200,
    borderRadius: 100,
    overflow: 'hidden',
    borderWidth: 3,
    borderColor: C.cardBorder,
    backgroundColor: '#1a1a2e',
  },
  avatarImage: {
    width: '100%',
    height: '100%',
  },

  /* TOOLS BAR */
  toolsBar: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    justifyContent: 'center',
    gap: SPACING.sm,
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.xl,
    marginTop: SPACING.xl,
    borderTopWidth: 1,
    borderTopColor: C.toolBorder,
    borderBottomWidth: 1,
    borderBottomColor: C.toolBorder,
    backgroundColor: C.toolBg,
  },
  toolChip: {
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.sm,
    borderRadius: RADIUS.sm,
    borderWidth: 1,
    borderColor: C.toolBorder,
    backgroundColor: C.card,
  },
  toolText: {
    fontFamily: FONTS.medium,
    fontSize: 13,
    color: C.textMuted,
    letterSpacing: 0.3,
  },

  /* DETAIL CARDS */
  detailsSection: {
    paddingHorizontal: SPACING.lg,
    paddingTop: SPACING.xxl,
    maxWidth: 960,
    width: '100%',
    alignSelf: 'center',
    gap: SPACING.lg,
    paddingBottom: SPACING.xl,
  },
  detailCard: {
    backgroundColor: C.card,
    borderRadius: RADIUS.lg,
    borderWidth: 1,
    borderColor: C.toolBorder,
    padding: SPACING.xl,
    gap: SPACING.md,
  },
  detailHeading: {
    fontFamily: FONTS.bold,
    fontSize: 17,
    color: C.accent,
    textTransform: 'uppercase',
    letterSpacing: 1.2,
  },
  chipRow: {
    flexDirection: 'row',
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  interestChip: {
    backgroundColor: C.chipBg,
    borderWidth: 1,
    borderColor: C.chipBorder,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.xs,
    borderRadius: RADIUS.pill,
  },
  interestChipText: {
    fontFamily: FONTS.medium,
    fontSize: 13,
    color: C.accent,
  },
  bulletRow: {
    flexDirection: 'row',
    alignItems: 'flex-start',
    gap: SPACING.sm,
  },
  bullet: {
    width: 6,
    height: 6,
    borderRadius: 3,
    backgroundColor: C.accent,
    marginTop: 8,
  },
  bulletText: {
    flex: 1,
    fontFamily: FONTS.regular,
    fontSize: 14,
    lineHeight: 22,
    color: C.textMuted,
  },
  goalCard: {
    borderColor: C.cardBorder,
    backgroundColor: 'rgba(26,127,212,0.06)',
  },
  goalText: {
    fontFamily: FONTS.regular,
    fontSize: 14,
    lineHeight: 23,
    color: C.textMuted,
    fontStyle: 'italic',
  },
});
