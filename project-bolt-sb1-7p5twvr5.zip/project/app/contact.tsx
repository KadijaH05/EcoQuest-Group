import { useState } from 'react';
import { View, Text, StyleSheet, ScrollView, Pressable, TextInput, KeyboardAvoidingView, Platform } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle2, MessageCircle } from 'lucide-react-native';
import { Ionicons } from '@expo/vector-icons';
import { COLORS, FONTS, RADIUS, SPACING, SHADOWS } from '@/lib/theme';
import { COMPANY } from '@/lib/ecoquest-data';
import { SectionHeader } from '@/components/PageSection';

const SOCIAL_ICONS: Record<string, keyof typeof Ionicons.glyphMap> = {
  instagram: 'logo-instagram',
  twitter: 'logo-twitter',
  email: 'mail-outline',
  globe: 'globe-outline',
};

export default function ContactScreen() {
  const insets = useSafeAreaInsets();
  const [name, setName] = useState('');
  const [email, setEmail] = useState('');
  const [message, setMessage] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const [error, setError] = useState<string | null>(null);

  function handleSubmit() {
    setError(null);
    if (!name.trim() || !email.trim() || !message.trim()) {
      setError('Please fill in your name, email, and message before sending.');
      return;
    }
    setSubmitted(true);
  }

  const CONTACT_ITEMS = [
    { icon: Mail, label: 'Email', value: COMPANY.contact.email },
    { icon: Phone, label: 'Phone', value: COMPANY.contact.phone },
    { icon: MapPin, label: 'Address', value: COMPANY.contact.address },
    { icon: Clock, label: 'Hours', value: COMPANY.contact.hours },
  ];

  return (
    <KeyboardAvoidingView
      style={styles.flex}
      behavior={Platform.OS === 'ios' ? 'padding' : undefined}
    >
      <ScrollView style={styles.container} contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxxl }}>
        <LinearGradient
          colors={[COLORS.heroDark, COLORS.heroGreen]}
          start={{ x: 0, y: 0 }}
          end={{ x: 1, y: 1 }}
          style={styles.header}
        >
          <View style={{ height: insets.top }} />
          <View style={styles.headerInner}>
            <View style={styles.headerIconWrap}>
              <MessageCircle color={COLORS.gold} size={26} strokeWidth={2.2} />
            </View>
            <Text style={styles.headerTitle}>Contact Us</Text>
            <Text style={styles.headerSubtitle}>
              Questions, partnership ideas, or want to bring ECOQUEST to your city? We would love to hear from you.
            </Text>
          </View>
        </LinearGradient>

        <View style={styles.section}>
          <SectionHeader eyebrow="Reach us" title="Get in touch" />

          <View style={styles.layout}>
            {/* CONTACT INFO */}
            <View style={styles.infoColumn}>
              {CONTACT_ITEMS.map((item) => {
                const Icon = item.icon;
                return (
                  <View key={item.label} style={styles.infoRow}>
                    <View style={styles.infoIconWrap}>
                      <Icon color={COLORS.primary} size={18} strokeWidth={2.2} />
                    </View>
                    <View>
                      <Text style={styles.infoLabel}>{item.label}</Text>
                      <Text style={styles.infoValue}>{item.value}</Text>
                    </View>
                  </View>
                );
              })}

              <View style={styles.socialsRow}>
                {COMPANY.socials.map((s) => {
                  const icon = SOCIAL_ICONS[s.type] ?? 'link-outline';
                  return (
                    <View key={s.label} style={styles.socialBtn}>
                      <Ionicons name={icon} size={18} color={COLORS.primary} />
                      <Text style={styles.socialLabel}>{s.label}</Text>
                    </View>
                  );
                })}
              </View>
            </View>

            {/* FORM */}
            <View style={styles.formColumn}>
              {submitted ? (
                <View style={styles.successCard}>
                  <CheckCircle2 color={COLORS.primary} size={40} strokeWidth={2} />
                  <Text style={styles.successTitle}>Message sent!</Text>
                  <Text style={styles.successText}>
                    Thanks, {name.split(' ')[0] || 'friend'}. We will get back to you within 1 to 2 business days.
                  </Text>
                  <Pressable
                    style={({ pressed }) => [styles.successReset, { opacity: pressed ? 0.85 : 1 }]}
                    onPress={() => {
                      setSubmitted(false);
                      setName('');
                      setEmail('');
                      setMessage('');
                    }}
                  >
                    <Text style={styles.successResetText}>Send another message</Text>
                  </Pressable>
                </View>
              ) : (
                <View style={styles.formCard}>
                  <Text style={styles.formLabel}>Your name</Text>
                  <TextInput
                    style={styles.input}
                    value={name}
                    onChangeText={setName}
                    placeholder="Jane Doe"
                    placeholderTextColor={COLORS.textDim}
                  />
                  <Text style={styles.formLabel}>Email address</Text>
                  <TextInput
                    style={styles.input}
                    value={email}
                    onChangeText={setEmail}
                    placeholder="jane@example.com"
                    placeholderTextColor={COLORS.textDim}
                    keyboardType="email-address"
                    autoCapitalize="none"
                  />
                  <Text style={styles.formLabel}>Message</Text>
                  <TextInput
                    style={[styles.input, styles.textArea]}
                    value={message}
                    onChangeText={setMessage}
                    placeholder="Tell us how we can help..."
                    placeholderTextColor={COLORS.textDim}
                    multiline
                    numberOfLines={4}
                    textAlignVertical="top"
                  />

                  {error ? (
                    <View style={styles.errorBanner}>
                      <Text style={styles.errorText}>{error}</Text>
                    </View>
                  ) : null}

                  <Pressable
                    style={({ pressed }) => [styles.submitBtn, { opacity: pressed ? 0.9 : 1 }]}
                    onPress={handleSubmit}
                  >
                    <Text style={styles.submitBtnText}>Send message</Text>
                    <Send color="#fff" size={16} strokeWidth={2.4} />
                  </Pressable>
                </View>
              )}
            </View>
          </View>
        </View>
      </ScrollView>
    </KeyboardAvoidingView>
  );
}

const styles = StyleSheet.create({
  flex: { flex: 1 },
  container: { flex: 1, backgroundColor: COLORS.bg },
  header: { width: '100%' },
  headerInner: { alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xxl, paddingTop: SPACING.xl, gap: SPACING.sm },
  headerIconWrap: { width: 56, height: 56, borderRadius: 18, alignItems: 'center', justifyContent: 'center', backgroundColor: 'rgba(255,255,255,0.12)', borderWidth: 1, borderColor: 'rgba(255,255,255,0.2)' },
  headerTitle: { fontFamily: FONTS.extraBold, fontSize: 32, color: '#fff' },
  headerSubtitle: { fontFamily: FONTS.regular, fontSize: 15, lineHeight: 23, color: 'rgba(255,255,255,0.85)', textAlign: 'center', maxWidth: 480 },
  section: { paddingHorizontal: SPACING.lg, paddingTop: SPACING.xxxl, maxWidth: 920, width: '100%', alignSelf: 'center', gap: SPACING.xl },
  layout: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.xl },
  infoColumn: { flex: 1, minWidth: 280, gap: SPACING.md },
  infoRow: { flexDirection: 'row', alignItems: 'center', gap: SPACING.md, backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.md, ...SHADOWS.soft },
  infoIconWrap: { width: 40, height: 40, borderRadius: 12, alignItems: 'center', justifyContent: 'center', backgroundColor: COLORS.accentSoft },
  infoLabel: { fontFamily: FONTS.medium, fontSize: 12, color: COLORS.textDim, textTransform: 'uppercase', letterSpacing: 1 },
  infoValue: { fontFamily: FONTS.semiBold, fontSize: 14, color: COLORS.text, marginTop: 2 },
  socialsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.sm, marginTop: SPACING.sm },
  socialBtn: { flexDirection: 'row', alignItems: 'center', gap: 6, backgroundColor: COLORS.card, borderWidth: 1, borderColor: COLORS.cardBorder, paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderRadius: RADIUS.pill },
  socialLabel: { fontFamily: FONTS.medium, fontSize: 12, color: COLORS.primary },
  formColumn: { flex: 1, minWidth: 300 },
  formCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.xl, gap: SPACING.sm, ...SHADOWS.soft },
  formLabel: { fontFamily: FONTS.medium, fontSize: 13, color: COLORS.text, marginTop: SPACING.xs },
  input: { backgroundColor: COLORS.surfaceLight, borderRadius: RADIUS.md, paddingHorizontal: SPACING.md, paddingVertical: SPACING.md, fontFamily: FONTS.regular, fontSize: 14, color: COLORS.text, borderWidth: 1, borderColor: COLORS.border },
  textArea: { minHeight: 110, paddingTop: SPACING.md },
  errorBanner: { backgroundColor: 'rgba(214,69,69,0.1)', borderRadius: RADIUS.md, padding: SPACING.md, borderWidth: 1, borderColor: 'rgba(214,69,69,0.25)', marginTop: SPACING.sm },
  errorText: { fontFamily: FONTS.regular, fontSize: 13, color: COLORS.danger },
  submitBtn: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: SPACING.sm, backgroundColor: COLORS.primary, paddingVertical: SPACING.md, borderRadius: RADIUS.pill, marginTop: SPACING.md, ...SHADOWS.button },
  submitBtnText: { fontFamily: FONTS.bold, fontSize: 15, color: '#fff' },
  successCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, borderColor: COLORS.cardBorder, padding: SPACING.xxl, alignItems: 'center', gap: SPACING.sm, ...SHADOWS.soft },
  successTitle: { fontFamily: FONTS.extraBold, fontSize: 22, color: COLORS.text },
  successText: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: COLORS.textMuted, textAlign: 'center', maxWidth: 360 },
  successReset: { marginTop: SPACING.sm, paddingVertical: SPACING.sm, paddingHorizontal: SPACING.lg, borderRadius: RADIUS.pill, borderWidth: 1.5, borderColor: COLORS.primary },
  successResetText: { fontFamily: FONTS.bold, fontSize: 13, color: COLORS.primary },
});
