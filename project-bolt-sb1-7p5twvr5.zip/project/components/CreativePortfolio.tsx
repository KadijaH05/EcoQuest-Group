import { useEffect } from 'react';
import { View, Text, StyleSheet, ScrollView, Image, Pressable, FlatList } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import Animated, { useSharedValue, useAnimatedStyle, withTiming, withDelay, Easing } from 'react-native-reanimated';
import { Palette, Sparkles, Mail, Brush, Heart } from 'lucide-react-native';
import { Ionicons } from '@expo/vector-icons';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { COLORS, FONTS, RADIUS, SPACING } from '@/lib/theme';
import type { PortfolioData } from '@/lib/portfolio-data';

const SOCIAL_ICONS: Record<string, keyof typeof Ionicons.glyphMap> = {
  instagram: 'logo-instagram',
  behance: 'logo-behance',
  dribbble: 'logo-dribbble',
  email: 'mail-outline',
  linkedin: 'logo-linkedin',
  twitter: 'logo-twitter',
};

export default function CreativePortfolio({ data }: { data: PortfolioData }) {
  const insets = useSafeAreaInsets();
  const t = data.theme;

  const progress = useSharedValue(0);

  useEffect(() => {
    progress.value = 0;
    progress.value = withTiming(1, { duration: 700, easing: Easing.out(Easing.cubic) });
  }, [data]);

  const heroStyle = useAnimatedStyle(() => ({
    opacity: progress.value,
    transform: [{ translateY: (1 - progress.value) * -12 }],
  }));
  const skillsStyle = useAnimatedStyle(() => ({
    opacity: withDelay(120, withTiming(progress.value, { duration: 500 })),
    transform: [{ translateY: (1 - progress.value) * 16 }],
  }));
  const projectsStyle = useAnimatedStyle(() => ({
    opacity: withDelay(240, withTiming(progress.value, { duration: 500 })),
    transform: [{ translateY: (1 - progress.value) * 20 }],
  }));
  const aboutStyle = useAnimatedStyle(() => ({
    opacity: withDelay(360, withTiming(progress.value, { duration: 500 })),
    transform: [{ translateY: (1 - progress.value) * 20 }],
  }));
  const contactStyle = useAnimatedStyle(() => ({
    opacity: withDelay(480, withTiming(progress.value, { duration: 500 })),
    transform: [{ translateY: (1 - progress.value) * 20 }],
  }));

  return (
    <ScrollView
      style={styles.container}
      contentContainerStyle={{ paddingBottom: insets.bottom + SPACING.xxl }}
    >
      {/* 1. Hero / Profile Header */}
      <LinearGradient
        colors={[t.gradientFrom, t.gradientTo]}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 1 }}
        style={styles.hero}
      >
        <View style={{ height: insets.top }} />
        <Animated.View style={[styles.heroInner, heroStyle]}>
          <View style={styles.avatarWrap}>
            <Image source={{ uri: data.avatar }} style={styles.avatar} />
            <View style={[styles.avatarRing, { borderColor: 'rgba(255,255,255,0.85)' }]} />
          </View>
          <Text style={styles.name}>{data.name}</Text>
          <Text style={styles.role}>{data.title}</Text>
          <Text style={styles.bio}>{data.bio}</Text>
        </Animated.View>
      </LinearGradient>

      {/* 2. Skills / Tools */}
      <Animated.View style={[styles.section, skillsStyle]}>
        <View style={styles.sectionHeader}>
          <Palette color={t.accent} size={20} strokeWidth={2.2} />
          <Text style={styles.sectionTitle}>Skills & Tools</Text>
        </View>
        <FlatList
          horizontal
          showsHorizontalScrollIndicator={false}
          data={data.skills}
          keyExtractor={(item) => item}
          contentContainerStyle={styles.skillsList}
          renderItem={({ item }) => (
            <View style={[styles.skillChip, { backgroundColor: t.chipBg, borderColor: t.chipBorder }]}>
              <Text style={[styles.skillChipText, { color: t.accentText }]}>{item}</Text>
            </View>
          )}
        />
      </Animated.View>

      {/* 3. Featured Work / Projects Grid */}
      <Animated.View style={[styles.section, projectsStyle]}>
        <View style={styles.sectionHeader}>
          <Sparkles color={t.accent} size={20} strokeWidth={2.2} />
          <Text style={styles.sectionTitle}>Featured Work</Text>
        </View>
        <View style={styles.projectsGrid}>
          {data.projects.map((p) => (
            <View key={p.title} style={[styles.projectCard, { borderColor: t.cardBorder }]}>
              <Image source={{ uri: p.thumbnail }} style={styles.projectThumb} />
              <View style={styles.projectBody}>
                <Text style={styles.projectCategory}>{p.category}</Text>
                <Text style={styles.projectTitle}>{p.title}</Text>
                <Text style={styles.projectDesc}>{p.description}</Text>
              </View>
            </View>
          ))}
        </View>
      </Animated.View>

      {/* 4. About / Process */}
      <Animated.View style={[styles.section, aboutStyle]}>
        <View style={styles.sectionHeader}>
          <Brush color={t.accent} size={20} strokeWidth={2.2} />
          <Text style={styles.sectionTitle}>About My Process</Text>
        </View>
        <View style={[styles.aboutCard, { borderColor: t.cardBorder }]}>
          <Text style={styles.aboutText}>{data.about}</Text>
          <View style={[styles.aboutAccent, { backgroundColor: t.accent }]} />
        </View>
      </Animated.View>

      {/* 5. Contact / Social Links */}
      <Animated.View style={[styles.section, contactStyle]}>
        <View style={styles.sectionHeader}>
          <Mail color={t.accent} size={20} strokeWidth={2.2} />
          <Text style={styles.sectionTitle}>Get in Touch</Text>
        </View>
        <View style={styles.socialsRow}>
          {data.socials.map((s) => {
            const icon = SOCIAL_ICONS[s.type] ?? 'link-outline';
            return (
              <Pressable
                key={s.label}
                style={({ pressed }) => [
                  styles.socialBtn,
                  { backgroundColor: t.chipBg, borderColor: t.chipBorder, opacity: pressed ? 0.8 : 1 },
                ]}
                onPress={() => undefined}
              >
                <Ionicons name={icon} size={20} color={t.accentText} />
                <Text style={[styles.socialLabel, { color: t.accentText }]}>{s.label}</Text>
              </Pressable>
            );
          })}
        </View>
        <View style={styles.footerRow}>
          <Heart color={COLORS.textDim} size={13} strokeWidth={2} />
          <Text style={styles.footerText}>Designed & built with care</Text>
        </View>
      </Animated.View>
    </ScrollView>
  );
}

const styles = StyleSheet.create({
  container: { flex: 1, backgroundColor: COLORS.bg },
  hero: { width: '100%' },
  heroInner: { alignItems: 'center', paddingHorizontal: SPACING.lg, paddingBottom: SPACING.xxl, paddingTop: SPACING.xl, gap: SPACING.sm },
  avatarWrap: { width: 132, height: 132, borderRadius: 66, alignItems: 'center', justifyContent: 'center', marginBottom: SPACING.xs },
  avatar: { width: 120, height: 120, borderRadius: 60, resizeMode: 'cover' },
  avatarRing: { position: 'absolute', width: 132, height: 132, borderRadius: 66, borderWidth: 3 },
  name: { fontFamily: FONTS.extraBold, fontSize: 32, color: '#fff', letterSpacing: 0.3, textAlign: 'center' },
  role: { fontFamily: FONTS.semiBold, fontSize: 16, color: 'rgba(255,255,255,0.92)', marginTop: 2 },
  bio: { fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: 'rgba(255,255,255,0.85)', textAlign: 'center', maxWidth: 460 },
  section: { paddingHorizontal: SPACING.lg, paddingTop: SPACING.xxl, maxWidth: 720, width: '100%', alignSelf: 'center', gap: SPACING.md },
  sectionHeader: { flexDirection: 'row', alignItems: 'center', gap: SPACING.sm },
  sectionTitle: { fontFamily: FONTS.bold, fontSize: 20, color: COLORS.text },
  skillsList: { gap: SPACING.sm, paddingVertical: SPACING.xs },
  skillChip: { paddingHorizontal: SPACING.md, paddingVertical: SPACING.sm, borderRadius: RADIUS.pill, borderWidth: 1, marginRight: SPACING.sm },
  skillChipText: { fontFamily: FONTS.medium, fontSize: 13 },
  projectsGrid: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md, justifyContent: 'center' },
  projectCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, overflow: 'hidden', minWidth: 260, maxWidth: 340, flex: 1 },
  projectThumb: { width: '100%', height: 150, resizeMode: 'cover' },
  projectBody: { padding: SPACING.md, gap: 4 },
  projectCategory: { fontFamily: FONTS.medium, fontSize: 11, color: COLORS.textDim, textTransform: 'uppercase', letterSpacing: 1 },
  projectTitle: { fontFamily: FONTS.bold, fontSize: 16, color: COLORS.text },
  projectDesc: { fontFamily: FONTS.regular, fontSize: 13, lineHeight: 20, color: COLORS.textMuted },
  aboutCard: { backgroundColor: COLORS.card, borderRadius: RADIUS.lg, borderWidth: 1, padding: SPACING.lg, flexDirection: 'row', gap: SPACING.md },
  aboutText: { flex: 1, fontFamily: FONTS.regular, fontSize: 14, lineHeight: 22, color: COLORS.textMuted },
  aboutAccent: { width: 3, borderRadius: 2 },
  socialsRow: { flexDirection: 'row', flexWrap: 'wrap', gap: SPACING.md },
  socialBtn: { flexDirection: 'row', alignItems: 'center', gap: SPACING.xs, paddingHorizontal: SPACING.lg, paddingVertical: SPACING.md, borderRadius: RADIUS.pill, borderWidth: 1 },
  socialLabel: { fontFamily: FONTS.medium, fontSize: 13 },
  footerRow: { flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 6, marginTop: SPACING.md },
  footerText: { fontFamily: FONTS.regular, fontSize: 12, color: COLORS.textDim },
});
