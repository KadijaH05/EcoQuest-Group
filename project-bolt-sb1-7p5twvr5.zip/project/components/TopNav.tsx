import { Pressable, Text, View, StyleSheet } from 'react-native';
import { LinearGradient } from 'expo-linear-gradient';
import { usePathname, router } from 'expo-router';
import { Home, ShoppingBag, Wrench, Users, Info, Mail, Palette, Brush } from 'lucide-react-native';
import { COLORS, FONTS, RADIUS, SPACING } from '@/lib/theme';

const TABS = [
  { label: 'Home', href: '/', icon: Home },
  { label: 'Catalog', href: '/catalog', icon: ShoppingBag },
  { label: 'Solutions', href: '/solutions', icon: Wrench },
  { label: 'Customers', href: '/customers', icon: Users },
  { label: 'About', href: '/about', icon: Info },
  { label: 'Contact', href: '/contact', icon: Mail },
  { label: 'Kadija', href: '/portfolio-maya', icon: Palette },
  { label: 'Destiny', href: '/portfolio-leo', icon: Brush },
];

export default function TopNav() {
  const pathname = usePathname();

  function isActive(href: string) {
    if (href === '/') return pathname === '/';
    return pathname.startsWith(href);
  }

  return (
    <View style={styles.container}>
      <LinearGradient
        colors={[COLORS.heroDark, '#0c2417']}
        start={{ x: 0, y: 0 }}
        end={{ x: 1, y: 0 }}
        style={styles.gradient}
      >
        <View style={styles.inner}>
          <Pressable style={styles.logoWrap} onPress={() => router.push('/')}>
            <View style={styles.logoDot} />
            <Text style={styles.logoText}>ECOQUEST</Text>
          </Pressable>

          <View style={styles.tabsRow}>
            {TABS.map((tab) => {
              const active = isActive(tab.href);
              const Icon = tab.icon;
              const isPortfolio = tab.href.startsWith('/portfolio');
              return (
                <Pressable
                  key={tab.href}
                  style={({ pressed }) => [
                    styles.tab,
                    active && styles.tabActive,
                    isPortfolio && styles.tabPortfolio,
                    { opacity: pressed ? 0.8 : 1 },
                  ]}
                  onPress={() => router.push(tab.href as any)}
                >
                  <Icon
                    size={15}
                    color={active ? COLORS.accent : isPortfolio ? COLORS.gold : COLORS.textMuted}
                    strokeWidth={2}
                  />
                  <Text style={[styles.tabText, active && styles.tabTextActive, isPortfolio && !active && styles.tabTextPortfolio]}>
                    {tab.label}
                  </Text>
                  {active && <View style={styles.tabIndicator} />}
                </Pressable>
              );
            })}
          </View>
        </View>
      </LinearGradient>
    </View>
  );
}

const styles = StyleSheet.create({
  container: {
    width: '100%',
    borderBottomWidth: 1,
    borderBottomColor: COLORS.border,
  },
  gradient: {
    width: '100%',
  },
  inner: {
    maxWidth: 1100,
    width: '100%',
    alignSelf: 'center',
    flexDirection: 'row',
    alignItems: 'center',
    justifyContent: 'space-between',
    paddingHorizontal: SPACING.lg,
    paddingVertical: SPACING.md,
    flexWrap: 'wrap',
    gap: SPACING.sm,
  },
  logoWrap: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.sm,
  },
  logoDot: {
    width: 12,
    height: 12,
    borderRadius: 6,
    backgroundColor: COLORS.accent,
  },
  logoText: {
    fontFamily: FONTS.extraBold,
    fontSize: 20,
    color: COLORS.text,
    letterSpacing: 1,
  },
  tabsRow: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: SPACING.xs,
    flexWrap: 'wrap',
  },
  tab: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: 5,
    paddingHorizontal: SPACING.md,
    paddingVertical: SPACING.sm,
    borderRadius: RADIUS.md,
    position: 'relative',
  },
  tabActive: {
    backgroundColor: 'rgba(124,198,66,0.1)',
  },
  tabPortfolio: {
    borderLeftWidth: 1,
    borderLeftColor: 'rgba(255,255,255,0.1)',
    marginLeft: SPACING.xs,
    paddingLeft: SPACING.md,
  },
  tabText: {
    fontFamily: FONTS.medium,
    fontSize: 13,
    color: COLORS.textMuted,
  },
  tabTextActive: {
    color: COLORS.text,
  },
  tabTextPortfolio: {
    color: COLORS.gold,
  },
  tabIndicator: {
    position: 'absolute',
    bottom: -SPACING.md - 2,
    left: SPACING.md,
    right: SPACING.md,
    height: 2,
    backgroundColor: COLORS.accent,
    borderRadius: 1,
  },
});
