import { View, Text, StyleSheet } from 'react-native';
import { COLORS, FONTS, SPACING } from '@/lib/theme';

export function SectionHeader({
  eyebrow,
  title,
  subtitle,
  center,
}: {
  eyebrow?: string;
  title: string;
  subtitle?: string;
  center?: boolean;
}) {
  return (
    <View style={[styles.wrap, center && styles.center]}>
      {eyebrow ? <Text style={styles.eyebrow}>{eyebrow}</Text> : null}
      <Text style={styles.title}>{title}</Text>
      {subtitle ? <Text style={styles.subtitle}>{subtitle}</Text> : null}
    </View>
  );
}

const styles = StyleSheet.create({
  wrap: { gap: SPACING.xs, maxWidth: 640, width: '100%' },
  center: { alignItems: 'center', alignSelf: 'center', textAlign: 'center' },
  eyebrow: {
    fontFamily: FONTS.bold,
    fontSize: 12,
    color: COLORS.primary,
    letterSpacing: 1.5,
    textTransform: 'uppercase',
  },
  title: {
    fontFamily: FONTS.extraBold,
    fontSize: 30,
    lineHeight: 38,
    color: COLORS.text,
  },
  subtitle: {
    fontFamily: FONTS.regular,
    fontSize: 15,
    lineHeight: 23,
    color: COLORS.textMuted,
  },
});
