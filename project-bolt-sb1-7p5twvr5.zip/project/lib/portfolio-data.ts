export interface PortfolioProject {
  title: string;
  description: string;
  category: string;
  thumbnail: string;
}

export interface PortfolioData {
  name: string;
  title: string;
  bio: string;
  avatar: string;
  skills: string[];
  projects: PortfolioProject[];
  about: string;
  socials: { label: string; type: 'instagram' | 'behance' | 'dribbble' | 'email' | 'linkedin' | 'twitter'; url: string }[];
  theme: {
    gradientFrom: string;
    gradientTo: string;
    accent: string;
    accentSoft: string;
    accentText: string;
    chipBg: string;
    chipBorder: string;
    cardBorder: string;
  };
}

export const PORTFOLIOS: Record<'one' | 'two', PortfolioData> = {
  one: {
    name: 'Maya Rivera',
    title: 'Graphic Designer',
    bio: 'Bold visuals, playful color, and stories told through type. I help brands find their visual voice.',
    avatar:
      'https://images.pexels.com/photos/2992517/pexels-photo-2992517.jpeg?auto=compress&cs=tinysrgb&w=700',
    skills: ['Figma', 'Illustrator', 'Photoshop', 'After Effects', 'Procreate', 'InDesign', 'Blender'],
    projects: [
      {
        title: 'Solstice Festival',
        description: 'Brand identity and poster series for a summer music festival.',
        category: 'Branding',
        thumbnail:
          'https://images.pexels.com/photos/3964758/pexels-photo-3964758.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
      {
        title: 'Urban Type',
        description: 'Experimental typography drawn from city signage and street posters.',
        category: 'Typography',
        thumbnail:
          'https://images.pexels.com/photos/3964576/pexels-photo-3964576.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
      {
        title: 'Color Theory',
        description: 'A study of geometric color relationships and visual rhythm.',
        category: 'Print Design',
        thumbnail:
          'https://images.pexels.com/photos/33485199/pexels-photo-33485199.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
      {
        title: 'Mural Series',
        description: 'Large-scale wall murals commissioned for a community arts district.',
        category: 'Mural Art',
        thumbnail:
          'https://images.pexels.com/photos/37484718/pexels-photo-37484718.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
    ],
    about:
      'I believe great design starts with listening. My process blends research, rough sketches, and rapid iteration \u2014 I move fast in the early stages and slow down when it matters. I draw inspiration from street art, vintage posters, and the everyday textures of the city. Every project is a conversation between brand and audience, and my job is to make that conversation feel effortless.',
    socials: [
      { label: 'Instagram', type: 'instagram', url: 'https://instagram.com' },
      { label: 'Behance', type: 'behance', url: 'https://behance.net' },
      { label: 'Email', type: 'email', url: 'mailto:maya@example.com' },
    ],
    theme: {
      gradientFrom: '#ff5e62',
      gradientTo: '#ff9966',
      accent: '#ff5e62',
      accentSoft: 'rgba(255,94,98,0.15)',
      accentText: '#ff7a6b',
      chipBg: 'rgba(255,94,98,0.12)',
      chipBorder: 'rgba(255,94,98,0.3)',
      cardBorder: 'rgba(255,94,98,0.2)',
    },
  },
  two: {
    name: 'Leo Okada',
    title: 'Illustrator',
    bio: 'Character-driven illustrations and editorial art. I turn ideas into images people remember.',
    avatar:
      'https://images.pexels.com/photos/32462167/pexels-photo-32462167.jpeg?auto=compress&cs=tinysrgb&w=700',
    skills: ['Procreate', 'Photoshop', 'Clip Studio Paint', 'Krita', 'Blender', 'ZBrush', 'Figma'],
    projects: [
      {
        title: 'Night Creatures',
        description: 'A children\u2019s book series following nocturnal animals on moonlit adventures.',
        category: 'Editorial',
        thumbnail:
          'https://images.pexels.com/photos/35707905/pexels-photo-35707905.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
      {
        title: 'Digital Sketchbook',
        description: 'A year-long daily drawing project exploring character and mood.',
        category: 'Illustration',
        thumbnail:
          'https://images.pexels.com/photos/7117279/pexels-photo-7117279.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
      {
        title: 'Sphere Studies',
        description: 'Abstract 3D illustration exploring light, form, and color.',
        category: '3D Art',
        thumbnail:
          'https://images.pexels.com/photos/34205961/pexels-photo-34205961.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
      {
        title: 'Flow Lines',
        description: 'A series of flowing geometric compositions for editorial spreads.',
        category: 'Abstract',
        thumbnail:
          'https://images.pexels.com/photos/32724737/pexels-photo-32724737.jpeg?auto=compress&cs=tinysrgb&w=700',
      },
    ],
    about:
      'My illustrations live where storytelling meets craft. I start every piece with a question \u2014 what is this character feeling, what is this scene hiding? \u2014 and let the answer shape the composition. I work in both digital and traditional media, and I\u2019m happiest when a drawing feels alive on the page. When I\u2019m not illustrating, I\u2019m studying old animation and collecting vintage comics.',
    socials: [
      { label: 'Instagram', type: 'instagram', url: 'https://instagram.com' },
      { label: 'Dribbble', type: 'dribbble', url: 'https://dribbble.com' },
      { label: 'Email', type: 'email', url: 'mailto:leo@example.com' },
    ],
    theme: {
      gradientFrom: '#3a7bd5',
      gradientTo: '#00d2ff',
      accent: '#00b4d8',
      accentSoft: 'rgba(0,180,216,0.15)',
      accentText: '#48cae4',
      chipBg: 'rgba(0,180,216,0.12)',
      chipBorder: 'rgba(0,180,216,0.3)',
      cardBorder: 'rgba(0,180,216,0.2)',
    },
  },
};
