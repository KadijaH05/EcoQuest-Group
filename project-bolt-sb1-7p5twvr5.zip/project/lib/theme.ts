export const COLORS = {
  bg: '#f4f7f2',
  surface: '#ffffff',
  surfaceLight: '#eef4ec',
  border: '#dfe8db',
  text: '#14201a',
  textMuted: '#4b5d52',
  textDim: '#7a8c81',
  primary: '#1f8a4c',
  primaryHover: '#176b39',
  accent: '#7cc642',
  accentSoft: 'rgba(124,198,66,0.16)',
  accentGlow: 'rgba(124,198,66,0.45)',
  gold: '#f6c945',
  goldDeep: '#e0a93b',
  card: '#ffffff',
  cardBorder: '#dfe8db',
  heroDark: '#0e2b1c',
  heroGreen: '#14532d',
  danger: '#d64545',
};

export const SPACING = {
  xs: 4,
  sm: 8,
  md: 16,
  lg: 24,
  xl: 32,
  xxl: 48,
  xxxl: 64,
};

export const RADIUS = {
  sm: 8,
  md: 12,
  lg: 16,
  xl: 24,
  pill: 999,
};

export const SHADOWS = {
  card: {
    shadowColor: '#1f8a4c',
    shadowOffset: { width: 0, height: 4 },
    shadowOpacity: 0.12,
    shadowRadius: 16,
    elevation: 4,
  },
  button: {
    shadowColor: '#1f8a4c',
    shadowOffset: { width: 0, height: 6 },
    shadowOpacity: 0.3,
    shadowRadius: 20,
    elevation: 6,
  },
  soft: {
    shadowColor: '#000',
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.06,
    shadowRadius: 12,
    elevation: 2,
  },
};

export const FONTS = {
  regular: 'Poppins-Regular',
  medium: 'Poppins-Medium',
  semiBold: 'Poppins-SemiBold',
  bold: 'Poppins-Bold',
  extraBold: 'Poppins-ExtraBold',
  mono: 'Poppins-Regular',
};
