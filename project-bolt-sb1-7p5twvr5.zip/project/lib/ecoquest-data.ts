export interface EcoFeature {
  icon: 'camera' | 'map' | 'award' | 'trophy' | 'recycle' | 'users';
  title: string;
  description: string;
}

export interface EcoStep {
  num: string;
  title: string;
  description: string;
}

export interface EcoStat {
  value: string;
  label: string;
}

export interface CatalogItem {
  name: string;
  description: string;
  priceCoins: number;
  category: string;
  image: string;
  stock: number;
}

export interface Testimonial {
  name: string;
  role: string;
  quote: string;
  avatar: string;
}

export interface BadgePreview {
  name: string;
  description: string;
  emoji: string;
  xp: number;
}

export interface SocialLink {
  label: string;
  type: 'instagram' | 'twitter' | 'email' | 'globe';
  url: string;
}

export const ECOQUEST = {
  name: 'ECOQUEST',
  slogan: 'Turning your community into a winning game',
  tagline: 'Get paid to pick up trash. Earn XP, collect badges, and clean up your neighborhood.',
  heroTruck:
    'https://images.pexels.com/photos/33799588/pexels-photo-33799588.jpeg?auto=compress&cs=tinysrgb&w=1200',
  heroTruckAlt:
    'https://images.pexels.com/photos/35436630/pexels-photo-35436630.jpeg?auto=compress&cs=tinysrgb&w=900',
};

export const COMMUNITY_IMAGES = {
  cleanup1:
    'https://images.pexels.com/photos/7656992/pexels-photo-7656992.jpeg?auto=compress&cs=tinysrgb&w=900',
  cleanup2:
    'https://images.pexels.com/photos/9324308/pexels-photo-9324308.jpeg?auto=compress&cs=tinysrgb&w=900',
  cleanup3:
    'https://images.pexels.com/photos/9543411/pexels-photo-9543411.jpeg?auto=compress&cs=tinysrgb&w=900',
  cleanup4:
    'https://images.pexels.com/photos/36713507/pexels-photo-36713507.jpeg?auto=compress&cs=tinysrgb&w=900',
  cleanup5:
    'https://images.pexels.com/photos/7656742/pexels-photo-7656742.jpeg?auto=compress&cs=tinysrgb&w=900',
  cleanup6:
    'https://images.pexels.com/photos/36713478/pexels-photo-36713478.jpeg?auto=compress&cs=tinysrgb&w=900',
  group:
    'https://images.pexels.com/photos/8555016/pexels-photo-8555016.jpeg?auto=compress&cs=tinysrgb&w=900',
};

export const STATS: EcoStat[] = [
  { value: '12,400+', label: 'Cleanups logged' },
  { value: '3.2M', label: 'Items collected' },
  { value: '8,900', label: 'Active eco-heroes' },
  { value: '180+', label: 'Neighborhoods' },
];

export const FEATURES: EcoFeature[] = [
  {
    icon: 'camera',
    title: 'Snap & Verify',
    description:
      'Take a photo of the trash you collect. Our verification confirms your cleanup in seconds.',
  },
  {
    icon: 'map',
    title: 'Real-Time Logging',
    description:
      'GPS tags every cleanup so your community can see exactly where neighborhoods are getting cleaner.',
  },
  {
    icon: 'award',
    title: 'Earn XP & Badges',
    description:
      'Every verified cleanup earns XP and unlocks badges. Climb the ranks from Rookie to Eco Legend.',
  },
  {
    icon: 'trophy',
    title: 'Cleanup Rewards',
    description:
      'Cash out your coins for real rewards or donate them to local community initiatives.',
  },
  {
    icon: 'recycle',
    title: 'Track Your Impact',
    description:
      'Watch your personal dashboard fill up with bags filled, items saved, and neighborhoods helped.',
  },
  {
    icon: 'users',
    title: 'Community Leaderboards',
    description:
      'Compete with neighbors and friends. Top cleaners earn bonus rewards and city-wide recognition.',
  },
];

export const STEPS: EcoStep[] = [
  {
    num: '01',
    title: 'Spot the Trash',
    description:
      'Open ECOQUEST and find a spot in your neighborhood that needs cleaning \u2014 a park, sidewalk, or beach.',
  },
  {
    num: '02',
    title: 'Snap & Log',
    description:
      'Pick up the trash, snap a before-and-after photo, and log the location. Verification happens instantly.',
  },
  {
    num: '03',
    title: 'Earn XP & Coins',
    description:
      'Each verified cleanup awards XP and ECO coins based on items collected and bags filled.',
  },
  {
    num: '04',
    title: 'Redeem Rewards',
    description:
      'Spend your coins in the catalog on gear, gift cards, or donate them to community projects.',
  },
];

export const BADGES: BadgePreview[] = [
  { name: 'First Steps', description: 'Log your first cleanup', emoji: '🌱', xp: 50 },
  { name: 'Trash Buster', description: 'Collect 100 items', emoji: '🛡️', xp: 200 },
  { name: 'Bag Filler', description: 'Fill 10 bags of trash', emoji: '🎒', xp: 350 },
  { name: 'Neighborhood Hero', description: 'Clean in 5 different locations', emoji: '🏙️', xp: 500 },
  { name: 'Eco Streak', description: 'Clean up 7 days in a row', emoji: '🔥', xp: 600 },
  { name: 'Eco Legend', description: 'Reach level 20', emoji: '👑', xp: 2000 },
];

export const CATALOG: CatalogItem[] = [
  {
    name: 'ECOQUEST Reusable Bottle',
    description: 'Stainless steel insulated water bottle with the ECOQUEST leaf logo.',
    priceCoins: 120,
    category: 'Gear',
    stock: 240,
    image:
      'https://images.pexels.com/photos/4519473/pexels-photo-4519473.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    name: 'Eco Hero Tote Bag',
    description: 'Organic cotton tote \u2014 perfect for grocery runs and cleanup days.',
    priceCoins: 80,
    category: 'Apparel',
    stock: 500,
    image:
      'https://images.pexels.com/photos/1214212/pexels-photo-1214212.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    name: 'Cleanup Gloves Kit',
    description: 'Durable reusable gloves plus a grabber tool for safe trash pickup.',
    priceCoins: 60,
    category: 'Gear',
    stock: 320,
    image:
      'https://images.pexels.com/photos/13704351/pexels-photo-13704351.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    name: 'Eco Hero Tee',
    description: 'Soft forest-green t-shirt with the ECOQUEST hero emblem on the chest.',
    priceCoins: 150,
    category: 'Apparel',
    stock: 180,
    image:
      'https://images.pexels.com/photos/5693888/pexels-photo-5693888.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    name: 'Coffee Tumbler',
    description: 'Keep your morning coffee hot while keeping single-use cups out of landfills.',
    priceCoins: 100,
    category: 'Gear',
    stock: 210,
    image:
      'https://images.pexels.com/photos/15123647/pexels-photo-15123647.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
  {
    name: 'Mesh Produce Bags',
    description: 'Set of 3 reusable mesh bags \u2014 a plastic-bag-free way to shop.',
    priceCoins: 45,
    category: 'Gear',
    stock: 640,
    image:
      'https://images.pexels.com/photos/18281431/pexels-photo-18281431.jpeg?auto=compress&cs=tinysrgb&w=600',
  },
];

export const TESTIMONIALS: Testimonial[] = [
  {
    name: 'Amara Johnson',
    role: 'Community Organizer · Oakland',
    quote:
      'ECOQUEST turned our weekend cleanups into a friendly competition. We collected 4,000 items in our first month \u2014 and the kids love earning badges.',
    avatar:
      'https://images.pexels.com/photos/7951669/pexels-photo-7951669.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
  {
    name: 'Marcus Lee',
    role: 'High School Student · Austin',
    quote:
      'I earned enough coins to buy a new water bottle and still had leftover for a gift card. Picking up trash actually pays off now.',
    avatar:
      'https://images.pexels.com/photos/5409261/pexels-photo-5409261.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
  {
    name: 'Priya Patel',
    role: 'Park Volunteer · Seattle',
    quote:
      'The real-time logging is amazing. I can see every park in my neighborhood getting cleaner on the map. It feels like a game I actually want to win.',
    avatar:
      'https://images.pexels.com/photos/5029775/pexels-photo-5029775.jpeg?auto=compress&cs=tinysrgb&w=200',
  },
];

export const SOLUTIONS = [
  {
    title: 'For Individuals',
    points: [
      'Snap, verify, and earn from every cleanup',
      'Climb the leaderboard and unlock badges',
      'Redeem coins for gear, gift cards, or donations',
      'Track your personal environmental impact',
    ],
  },
  {
    title: 'For Communities',
    points: [
      'Real-time map of neighborhood cleanups',
      'Organize group cleanup events and challenges',
      'Recognize top contributors with city-wide awards',
      'Keep public spaces clean and organized',
    ],
  },
  {
    title: 'For Cities & Partners',
    points: [
      'Aggregate data on litter hotspots and trends',
      'Sponsor reward programs for local residents',
      'Reduce municipal cleanup costs through crowdsourcing',
      'Engage citizens in measurable environmental action',
    ],
  },
];

export const COMPANY = {
  founded: '2024',
  mission:
    'ECOQUEST exists to make keeping neighborhoods clean fun, rewarding, and measurable. We turn everyday people into eco-heroes by paying them to pick up trash \u2014 one verified cleanup at a time.',
  story:
    'ECOQUEST started when two friends noticed their local park was always covered in litter. Instead of waiting for someone else to fix it, they built an app that pays people to clean it up. Today, thousands of eco-heroes across 180+ neighborhoods use ECOQUEST to turn their communities into a winning game.',
  values: [
    {
      icon: 'leaf' as const,
      title: 'Planet First',
      description: 'Every feature we build should leave the world cleaner than we found it.',
    },
    {
      icon: 'users' as const,
      title: 'Community Powered',
      description: 'Real change happens block by block, led by the people who live there.',
    },
    {
      icon: 'trophy' as const,
      title: 'Reward Real Action',
      description: 'We put our money where our mission is \u2014 paying people for verified cleanups.',
    },
    {
      icon: 'shield' as const,
      title: 'Transparent & Verified',
      description: 'Every cleanup is photo-verified and GPS-logged. No fake stats, ever.',
    },
  ] as { icon: 'leaf' | 'users' | 'trophy' | 'shield'; title: string; description: string }[],
  team: [
    { name: 'Kadija Hien', role: 'Co-Founder & Head of Design', href: '/portfolio-maya' },
    { name: 'Destiny Dada', role: 'Co-Founder & Lead Illustrator', href: '/portfolio-leo' },
  ],
  contact: {
    email: 'hello@ecoquest.app',
    phone: '(555) 012-3456',
    address: '240 Greenway Ave, Suite 12, Portland, OR 97204',
    hours: 'Mon\u2013Fri, 9am\u20136pm PT',
  },
  socials: [
    { label: 'Instagram', type: 'instagram' as const, url: 'https://instagram.com' },
    { label: 'Twitter', type: 'twitter' as const, url: 'https://twitter.com' },
    { label: 'Email', type: 'email' as const, url: 'mailto:hello@ecoquest.app' },
    { label: 'Website', type: 'globe' as const, url: 'https://ecoquest.app' },
  ] as SocialLink[],
};
