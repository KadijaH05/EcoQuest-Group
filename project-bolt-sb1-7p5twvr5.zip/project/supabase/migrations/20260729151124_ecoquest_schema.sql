/*
# ECOQUEST Community Cleanup App — Core Schema

## Overview
This migration creates the full database for ECOQUEST, a community cleanup gamification app.
Users earn XP and coins by logging verified cleanups (photo + location), level up, earn badges,
and spend coins on reward products from a browsable catalog.

## New Tables
1. `profiles` — one row per user. Holds display name, avatar URL, XP, coins, level, stats counters.
2. `cleanups` — each verified cleanup event logged by a user. Stores photo URL, lat/lng, location label, items collected, bags filled, XP/coins awarded, verification status, timestamp.
3. `badges` — achievement definitions (name, description, icon, criteria stored as JSON).
4. `user_badges` — junction recording which user earned which badge and when.
5. `catalog_items` — redeemable reward products (name, description, coin price, stock, image, category).

## Security (RLS)
- All tables RLS-enabled.
- profiles: authenticated read all (leaderboard), update only own.
- cleanups: authenticated read all (community feed), insert/update/delete only own.
- badges + catalog_items: readable by all authenticated (reference data).
- user_badges: authenticated read all, insert only own.

## Important Notes
1. Owner columns default to auth.uid() so client inserts omitting owner still pass RLS.
2. A trigger auto-creates a profiles row on signup.
3. Policies are idempotent (DROP IF EXISTS before CREATE).
*/

-- ---------- profiles ----------
CREATE TABLE IF NOT EXISTS profiles (
  id uuid PRIMARY KEY REFERENCES auth.users(id) ON DELETE CASCADE,
  email text,
  display_name text NOT NULL DEFAULT 'Eco Hero',
  avatar_url text,
  xp integer NOT NULL DEFAULT 0,
  coins integer NOT NULL DEFAULT 0,
  level integer NOT NULL DEFAULT 1,
  total_cleanups integer NOT NULL DEFAULT 0,
  total_items integer NOT NULL DEFAULT 0,
  total_bags integer NOT NULL DEFAULT 0,
  created_at timestamptz DEFAULT now(),
  updated_at timestamptz DEFAULT now()
);

ALTER TABLE profiles ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "profiles_select_all" ON profiles;
CREATE POLICY "profiles_select_all" ON profiles FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "profiles_insert_own" ON profiles;
CREATE POLICY "profiles_insert_own" ON profiles FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = id);

DROP POLICY IF EXISTS "profiles_update_own" ON profiles;
CREATE POLICY "profiles_update_own" ON profiles FOR UPDATE
  TO authenticated USING (auth.uid() = id) WITH CHECK (auth.uid() = id);

-- ---------- cleanups ----------
CREATE TABLE IF NOT EXISTS cleanups (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  photo_url text,
  latitude double precision,
  longitude double precision,
  location_label text NOT NULL DEFAULT 'Unknown location',
  items_collected integer NOT NULL DEFAULT 0,
  bags_filled numeric(5,2) NOT NULL DEFAULT 0,
  xp_awarded integer NOT NULL DEFAULT 0,
  coins_awarded integer NOT NULL DEFAULT 0,
  verified boolean NOT NULL DEFAULT true,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE cleanups ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "cleanups_select_all" ON cleanups;
CREATE POLICY "cleanups_select_all" ON cleanups FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "cleanups_insert_own" ON cleanups;
CREATE POLICY "cleanups_insert_own" ON cleanups FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "cleanups_update_own" ON cleanups;
CREATE POLICY "cleanups_update_own" ON cleanups FOR UPDATE
  TO authenticated USING (auth.uid() = user_id) WITH CHECK (auth.uid() = user_id);

DROP POLICY IF EXISTS "cleanups_delete_own" ON cleanups;
CREATE POLICY "cleanups_delete_own" ON cleanups FOR DELETE
  TO authenticated USING (auth.uid() = user_id);

CREATE INDEX IF NOT EXISTS cleanups_user_id_idx ON cleanups(user_id);
CREATE INDEX IF NOT EXISTS cleanups_created_at_idx ON cleanups(created_at DESC);

-- ---------- badges ----------
CREATE TABLE IF NOT EXISTS badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  icon text NOT NULL,
  category text NOT NULL DEFAULT 'cleanup',
  requirement jsonb NOT NULL DEFAULT '{}'::jsonb,
  created_at timestamptz DEFAULT now()
);

ALTER TABLE badges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "badges_select_all" ON badges;
CREATE POLICY "badges_select_all" ON badges FOR SELECT
  TO authenticated USING (true);

-- ---------- user_badges ----------
CREATE TABLE IF NOT EXISTS user_badges (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  user_id uuid NOT NULL DEFAULT auth.uid() REFERENCES auth.users(id) ON DELETE CASCADE,
  badge_id uuid NOT NULL REFERENCES badges(id) ON DELETE CASCADE,
  earned_at timestamptz DEFAULT now(),
  UNIQUE(user_id, badge_id)
);

ALTER TABLE user_badges ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "user_badges_select_all" ON user_badges;
CREATE POLICY "user_badges_select_all" ON user_badges FOR SELECT
  TO authenticated USING (true);

DROP POLICY IF EXISTS "user_badges_insert_own" ON user_badges;
CREATE POLICY "user_badges_insert_own" ON user_badges FOR INSERT
  TO authenticated WITH CHECK (auth.uid() = user_id);

-- ---------- catalog_items ----------
CREATE TABLE IF NOT EXISTS catalog_items (
  id uuid PRIMARY KEY DEFAULT gen_random_uuid(),
  name text NOT NULL,
  description text NOT NULL,
  price_coins integer NOT NULL DEFAULT 0,
  stock integer NOT NULL DEFAULT 0,
  image_url text,
  category text NOT NULL DEFAULT 'gear',
  created_at timestamptz DEFAULT now()
);

ALTER TABLE catalog_items ENABLE ROW LEVEL SECURITY;

DROP POLICY IF EXISTS "catalog_select_all" ON catalog_items;
CREATE POLICY "catalog_select_all" ON catalog_items FOR SELECT
  TO authenticated USING (true);

-- ---------- auto profile creation trigger ----------
CREATE OR REPLACE FUNCTION public.handle_new_user()
RETURNS trigger
LANGUAGE plpgsql
SECURITY DEFINER SET search_path = public
AS $$
BEGIN
  INSERT INTO public.profiles (id, email, display_name)
  VALUES (NEW.id, NEW.email, COALESCE(NEW.raw_user_meta_data->>'display_name', 'Eco Hero'))
  ON CONFLICT (id) DO NOTHING;
  RETURN NEW;
END;
$$;

DROP TRIGGER IF EXISTS on_auth_user_created ON auth.users;
CREATE TRIGGER on_auth_user_created
  AFTER INSERT ON auth.users
  FOR EACH ROW EXECUTE FUNCTION public.handle_new_user();