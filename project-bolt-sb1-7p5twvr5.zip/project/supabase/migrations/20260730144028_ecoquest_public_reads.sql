/*
# ECOQUEST — Enable public browsing of catalog and badges

## Purpose
The ECOQUEST app website lets visitors browse the reward catalog and view badge
definitions without signing in. The original migration scoped reads to
`authenticated` only, which blocks the anon-key frontend client from seeing any
rows. This migration updates the read policies on `catalog_items` and `badges`
so the public site can display them.

## Changes
1. `catalog_items` — replace the authenticated-only SELECT policy with a
   public SELECT policy (`TO anon, authenticated`). Writes remain admin-only
   (no anon insert/update/delete policy).
2. `badges` — replace the authenticated-only SELECT policy with a public
   SELECT policy (`TO anon, authenticated`).

## Security
- Reads of catalog items and badge definitions are intentionally public
  (reference data shown to all site visitors).
- No write access is granted to anon — inserts/updates/deletes are still
  blocked for unauthenticated users.
- `profiles`, `cleanups`, and `user_badges` policies are unchanged and remain
  authenticated-only (user-owned data).
*/

-- catalog_items: public read
DROP POLICY IF EXISTS "catalog_select_all" ON catalog_items;
CREATE POLICY "catalog_select_all" ON catalog_items FOR SELECT
  TO anon, authenticated USING (true);

-- badges: public read
DROP POLICY IF EXISTS "badges_select_all" ON badges;
CREATE POLICY "badges_select_all" ON badges FOR SELECT
  TO anon, authenticated USING (true);
